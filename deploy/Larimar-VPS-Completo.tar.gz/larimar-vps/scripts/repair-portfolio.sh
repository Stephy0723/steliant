#!/usr/bin/env bash
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo 'Ejecutar como root'; exit 1; }
dest=/var/www/steliant-portafolio
repo=/var/www/steliant.git
[[ -d "$repo/.git" && -d "$dest" ]] || { echo 'No coinciden las rutas verificadas del VPS'; exit 1; }
backup="/var/backups/portafolio-$(date +%Y%m%d-%H%M%S)"
stage=$(mktemp -d /tmp/portfolio-update.XXXXXX)
mkdir -p "$backup"
cp -a "$dest" "$backup/"
git -C "$repo" fetch origin gh-pages
git -C "$repo" archive origin/gh-pages | tar -x -C "$stage"
# Copia completa, sin borrar los archivos locales ni otras demos.
cp -a "$stage/." "$dest/"
# El montaje conocido de Nginx usa /steliant/demos; conservar las rutas antiguas también.
for dir in "$stage"/demos/*; do
  [[ -d "$dir" ]] || continue
  name=$(basename "$dir")
  mkdir -p "$dest/$name"
  cp -a "$dir/." "$dest/$name/"
done
printf 'Portafolio completo copiado. Respaldo: %s\n' "$backup"
printf 'Si aún hay 404, revisar locations y rutas /steliant/ en Nginx; no se modificó su configuración.\n'
