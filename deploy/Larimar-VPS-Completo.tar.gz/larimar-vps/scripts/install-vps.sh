#!/usr/bin/env bash
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo 'Ejecuta este instalador como root.'; exit 1; }
node_bin=$(command -v node || true)
[[ -n "$node_bin" ]] || { echo 'Falta Node.js 24. Instálalo antes de continuar.'; exit 1; }
"$node_bin" -e 'if(Number(process.versions.node.split(".")[0])<24)process.exit(1)' || { echo 'Se necesita Node.js 24 o superior.'; exit 1; }
package_root=$(cd "$(dirname "$0")/.." && pwd)
[[ -f "$package_root/dist-server/index.js" && -f "$package_root/dist/index.html" ]] || { echo 'Paquete incompleto'; exit 1; }
stamp=$(date +%Y%m%d-%H%M%S)
app_dir=/opt/steliant-larimar
data_dir=/var/lib/steliant-larimar
backup_dir="/var/backups/larimar-$stamp"
mkdir -p "$backup_dir"
if systemctl is-active --quiet steliant-larimar; then systemctl stop steliant-larimar; fi
trap 'echo "Instalación interrumpida. Respaldo disponible en: $backup_dir"; systemctl start steliant-larimar 2>/dev/null || true' ERR
[[ ! -d "$app_dir" ]] || cp -a "$app_dir" "$backup_dir/app"
[[ ! -d "$data_dir" ]] || cp -a "$data_dir" "$backup_dir/data"
id larimar-app >/dev/null 2>&1 || useradd --system --home "$data_dir" --shell /usr/sbin/nologin larimar-app
install -d -m 750 -o larimar-app -g larimar-app "$app_dir" "$data_dir"
install -d -m 755 /opt/steliant-node/bin
install -m 755 "$node_bin" /opt/steliant-node/bin/node
for entry in dist dist-server server scripts app public package.json vite.config.mjs vite.server.config.mjs seed.json README-VPS.md; do
  [[ ! -e "$package_root/$entry" ]] || cp -a "$package_root/$entry" "$app_dir/"
done
if [[ ! -f "$app_dir/.env" ]]; then
  printf 'Correo de la propietaria [steliantsoft@gmail.com]: '
  read -r owner_email </dev/tty
  owner_email=${owner_email:-steliantsoft@gmail.com}
  [[ "$owner_email" =~ ^[A-Za-z0-9._+%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]] || { echo 'Correo no válido'; exit 1; }
  printf 'PORT=4401\nBASE_PATH=/larimar\nDATA_DIR=/var/lib/steliant-larimar\nOWNER_EMAIL=%s\n' "$owner_email" > "$app_dir/.env"
  chmod 600 "$app_dir/.env"
fi
if [[ ! -f "$data_dir/larimar.sqlite" ]] || ! (cd "$app_dir" && /opt/steliant-node/bin/node --env-file=.env --input-type=module -e 'import {sql} from "./server/storage.mjs";process.exit(sql.prepare("SELECT count(*) AS n FROM users").get().n?0:1)'); then
  printf 'Contraseña del CRM (mínimo 12 caracteres): '
  read -rs owner_pass </dev/tty; printf '\n'
  printf 'Repite la contraseña: '
  read -rs owner_repeat </dev/tty; printf '\n'
  [[ "$owner_pass" == "$owner_repeat" && ${#owner_pass} -ge 12 ]] || { echo 'Las contraseñas no coinciden o son cortas'; exit 1; }
  (cd "$app_dir" && printf '%s' "$owner_pass" | /opt/steliant-node/bin/node --env-file=.env server/password.mjs)
  unset owner_pass owner_repeat
fi
chown -R larimar-app:larimar-app "$app_dir" "$data_dir"
cat > /etc/systemd/system/steliant-larimar.service <<'SERVICE'
[Unit]
Description=Steliant Larimar - tienda y CRM
After=network.target
[Service]
Type=simple
User=larimar-app
Group=larimar-app
WorkingDirectory=/opt/steliant-larimar
EnvironmentFile=/opt/steliant-larimar/.env
ExecStart=/opt/steliant-node/bin/node dist-server/index.js
Restart=on-failure
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/steliant-larimar
UMask=0077
[Install]
WantedBy=multi-user.target
SERVICE
systemctl daemon-reload
systemctl enable --now steliant-larimar
curl --fail --retry 8 --retry-connrefused --retry-delay 1 http://127.0.0.1:4401/larimar/health
printf '\nLarimar completo instalado en %s\n' "$app_dir"
printf 'Datos persistentes: %s\nRespaldo: %s\n' "$data_dir" "$backup_dir"
printf 'Falta conectar Nginx con el bloque de scripts/nginx-larimar.conf. No se cambió Nginx automáticamente.\n'
