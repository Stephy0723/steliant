import {spawn} from 'node:child_process';
const child=spawn(process.execPath,['dist-server/index.js'],{stdio:'inherit',env:{...process.env,PORT:process.env.PORT||'4173',DATA_DIR:'/tmp/larimar-preview-local',BASE_PATH:'/larimar',ALLOW_HTTP:'1'}});for(const sig of ['SIGINT','SIGTERM'])process.on(sig,()=>child.kill(sig));child.on('exit',c=>process.exit(c||0));
