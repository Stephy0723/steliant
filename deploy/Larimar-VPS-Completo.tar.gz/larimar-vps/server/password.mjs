import {setPassword,ownerEmail} from './auth.mjs';
let input='';for await(const chunk of process.stdin)input+=chunk;if(!input.trim())throw Error('La contraseña debe recibirse por entrada estándar');setPassword(process.argv[2]||ownerEmail,input.trim());console.log('Contraseña configurada. Sesiones anteriores cerradas.');
