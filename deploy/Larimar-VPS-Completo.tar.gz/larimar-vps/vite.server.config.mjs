import {defineConfig} from 'vite';import path from 'node:path';
export default defineConfig({publicDir:false,resolve:{alias:{'cloudflare:workers':path.resolve('server/storage.mjs')}},build:{ssr:'server/index.mjs',outDir:'dist-server',emptyOutDir:true,rollupOptions:{output:{entryFileNames:'index.js'}}}});
