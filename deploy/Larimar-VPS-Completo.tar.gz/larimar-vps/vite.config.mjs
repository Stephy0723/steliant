import {defineConfig} from 'vite';
export default defineConfig({base:(process.env.BASE_PATH||'/larimar').replace(/\/$/,'')+'/',build:{outDir:'dist',emptyOutDir:true},esbuild:{jsx:'automatic'}});
