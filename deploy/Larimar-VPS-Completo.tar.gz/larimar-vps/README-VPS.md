# Larimar completo para VPS

Versión con el mismo frontend y operaciones de tienda/CRM, backend Node.js 24, SQLite y fotos en disco. No usa ChatGPT para iniciar sesión. Catálogo público; CRM con correo y contraseña propios. Sin pasarela ni nómina.

## Datos

El catálogo de muestra se prepara al arrancar una base nueva. No se incluyen datos reales de clientes ni credenciales. Los datos que existan en la publicación de Sites no se trasladan automáticamente. En una empresa nueva, sustituir las piezas de referencia y configurar contacto, precios y políticas.

## Instalar

Extraer el paquete en una carpeta temporal y ejecutar `bash scripts/install-vps.sh`. Pide correo y contraseña en la terminal, no por chat. Instala aplicación y servicio independientes, escucha en 127.0.0.1:4401 y no modifica otros procesos.

El instalador requiere un Node.js 24 ya disponible en PATH. Copia ese ejecutable a /opt/steliant-node/bin/node para que systemd no dependa de NVM ni del directorio de root. No ejecuta actualizaciones de Ubuntu.

Después incluir `scripts/nginx-larimar.conf` dentro del bloque HTTPS del dominio del portafolio, probar `nginx -t` y recargar Nginx. Verificar /larimar/, /larimar/login y /larimar/#crm.

Solo después de que Nginx sirva correctamente el sistema: `node scripts/link-live-demo.mjs /var/www/steliant-portafolio/index.html`.

## Demos anteriores

`scripts/repair-portfolio.sh` copia el portafolio completo desde gh-pages y conserva los archivos locales. Hace un respaldo antes y replica las carpetas de demos en las dos ubicaciones usadas por el VPS. Los 404 por rutas absolutas /steliant/ requieren comprobar el bloque Nginx; el script no altera su configuración.

## Equipo

Entrar con la cuenta propietaria y crear usuarios en Usuarios y permisos, con una contraseña inicial de al menos 12 caracteres. Un vendedor solo accede a ventas, clientes, cobros y entregas; inventario tiene sus propios permisos. Para una demostración, crear una cuenta del equipo y usar datos de ensayo. No compartir la contraseña propietaria.

Las sesiones duran 12 horas, usan cookies HttpOnly/SameSite y Secure bajo HTTPS, y se invalidan al cambiar contraseña. El inicio de sesión limita intentos. El servidor solo escucha en loopback; Nginx debe pasar X-Real-IP y X-Forwarded-Proto.

## Persistencia y respaldo

La base está en /var/lib/steliant-larimar/larimar.sqlite y fotos/copias en files/. Actualizar la aplicación no borra ese directorio. Las copias internas siguen disponibles desde el CRM. Para respaldo externo completo, parar el servicio y copiar el directorio de datos completo, o usar una copia SQLite consistente junto con files/. Mantener esos respaldos privados.

## Actualizar y probar

Los archivos fuente están incluidos. Para recompilar: npm install, npm run build. Base de rutas por defecto /larimar. No cambiarla sin recompilar y revisar Nginx.

Pruebas: npm test; node scripts/check-vps.mjs. La prueba del VPS utiliza una base temporal, verifica login local, roles, solicitudes, inventario, carga de imágenes y restauración. No sustituye comprobar el dominio real después de instalar.

La previsualización visual de esta entrega no pudo completarse por la conexión del navegador de pruebas. No se ha instalado automáticamente en el VPS: la red de esta sesión no puede acceder a 62.84.179.229.
