const known:Record<string,string>={'Larimar':'Larimar','Plata 925':'Sterling silver 925','Oro':'Gold','Plata':'Silver','No aplica':'Not applicable','Reverso cerrado':'Closed back','Reverso cerrado en plata':'Closed silver back','Cadena no incluida':'Chain not included','Anillo · una pieza':'Ring · one piece','Colgante · cadena por separado':'Pendant · chain sold separately','Pulsera · una pieza':'Bracelet · one piece'};
export function splitTranslation(text:string,maxBytes=450){const chunks:string[]=[];let current='';const encoder=new TextEncoder();for(const token of text.split(/(\s+)/u)){for(const char of token){if(encoder.encode(current+char).length>maxBytes){let cut=current.lastIndexOf(' ');if(cut>current.length/2){chunks.push(current.slice(0,cut));current=current.slice(cut+1)}else{chunks.push(current);current=''}}current+=char}}if(current.trim())chunks.push(current);return chunks.filter(chunk=>chunk.trim())}
export function decodeTranslation(text:string){return text.replace(/&#x([0-9a-f]+);/gi,(_,h)=>{const n=parseInt(h,16);return n<=0x10ffff?String.fromCodePoint(n):''}).replace(/&#(\d+);/g,(_,d)=>{const n=Number(d);return n<=0x10ffff?String.fromCodePoint(n):''}).replace(/&quot;/g,'"').replace(/&apos;|&#39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&')}
export async function translateText(text:string,db:any,fetcher:typeof fetch=fetch){
 const source=text.trim();if(!source)return '';
 if(known[source])return known[source];
 if(/^[\d\s.,×x≈°%½¼¾/()\-–+]+(?:\s*(?:g|gr|kg|mm|cm|m|US|EU|in|oz|k|K))*$/u.test(source))return source;
 const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode('es|en|v1|'+source)))).map(b=>b.toString(16).padStart(2,'0')).join('');const id='translation:'+hash;
 const cached=await db.prepare("SELECT data FROM records WHERE id=? AND kind='translation'").bind(id).first();if(cached){const c=JSON.parse(cached.data);if(c.source===source&&c.text)return c.text}
 if(source.length>10000)throw Error('El texto es demasiado largo para traducirlo de una vez');
 const translated=[];
 for(const chunk of splitTranslation(source)){
 const url=new URL('https://api.mymemory.translated.net/get');url.searchParams.set('q',chunk.trim());url.searchParams.set('langpair','es|en');url.searchParams.set('mt','1');
 const response=await fetcher(url,{signal:AbortSignal.timeout(12000),headers:{Accept:'application/json'}});if(!response.ok)throw Error('El servicio de traducción no está disponible');
 const data:any=await response.json();const value=data.responseData?.translatedText;
 if(Number(data.responseStatus)!==200||data.quotaFinished||typeof value!=='string'||!value.trim()||/MYMEMORY WARNING|QUERY LENGTH LIMIT|PLEASE SELECT TWO DISTINCT|USED ALL AVAILABLE FREE TRANSLATIONS/i.test(value))throw Error('El servicio de traducción está temporalmente limitado');
 translated.push(decodeTranslation(value));
 }
 const result=translated.join(' ');await db.prepare('INSERT INTO records(id,kind,data) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data').bind(id,'translation',JSON.stringify({id,kind:'translation',source,text:result,target:'en',provider:'MyMemory',date:new Date().toISOString()})).run();return result;
}
