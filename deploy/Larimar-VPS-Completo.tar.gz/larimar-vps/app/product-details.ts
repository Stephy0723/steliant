export const referenceDetails:Record<string,any> = {
  "p1": {
    "material": "Plata 925",
    "weight": "16 g",
    "dimensions": "27 × 20 × 11 mm",
    "size": "US 7¾",
    "setting": "Reverso cerrado en plata",
    "chain": "No aplica",
    "includes": "Anillo · una pieza",
    "stone": "Larimar",
    "gallery": [
      {
        "url": "/jewels/p1-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/p1-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/p1-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/p1-3.jpg",
        "label": "4"
      },
      {
        "url": "/jewels/p1-4.jpg",
        "label": "5"
      }
    ],
    "image": "/jewels/p1-0.jpg",
    "sku": "LA-P1-01",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/teardrop-larimar-ring-treisi",
    "materialEn": "Sterling silver 925",
    "settingEn": "Closed silver back",
    "chainEn": "Not applicable",
    "includesEn": "Ring · one piece"
  },
  "p2": {
    "material": "Plata 925",
    "weight": "22 g",
    "dimensions": "54 × 20 × 12 mm",
    "setting": "Reverso cerrado",
    "chain": "Cadena no incluida",
    "includes": "Colgante · cadena por separado",
    "stone": "Larimar",
    "gallery": [
      {
        "url": "/jewels/p2-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/p2-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/p2-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/p2-3.jpg",
        "label": "4"
      },
      {
        "url": "/jewels/p2-4.jpg",
        "label": "5"
      },
      {
        "url": "/jewels/p2-5.jpg",
        "label": "6"
      }
    ],
    "image": "/jewels/p2-0.jpg",
    "sku": "LA-P2-01",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/larimar-triangle-pendant-thalia",
    "materialEn": "Sterling silver 925",
    "settingEn": "Closed back",
    "chainEn": "Chain not included",
    "includesEn": "Pendant · chain sold separately"
  },
  "p3": {
    "material": "Oro vermeil · quilataje por confirmar",
    "weight": "9 g",
    "dimensions": "Piedra: 23 × 12 × 8 mm",
    "size": "US 6¾",
    "setting": "Reverso cerrado en plata",
    "chain": "No aplica",
    "includes": "Anillo · una pieza",
    "stone": "Larimar",
    "gallery": [
      {
        "url": "/jewels/p3-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/p3-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/p3-3.jpg",
        "label": "4"
      },
      {
        "url": "/jewels/p3-4.jpg",
        "label": "5"
      }
    ],
    "image": "/jewels/p3-0.jpg",
    "sku": "LA-P3-01",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/gold-vermeil-larimar-ring-ava",
    "materialEn": "Gold vermeil · fineness to be confirmed",
    "dimensionsEn": "Stone: 23 × 12 × 8 mm",
    "settingEn": "Closed silver back",
    "chainEn": "Not applicable",
    "includesEn": "Ring · one piece"
  },
  "p4": {
    "material": "Plata 925",
    "weight": "7 g",
    "dimensions": "31 × 10 × 7 mm",
    "setting": "Reverso cerrado en plata",
    "includes": "Aretes · confirmar presentación",
    "stone": "Larimar",
    "gallery": [
      {
        "url": "/jewels/p4-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/p4-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/p4-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/p4-3.jpg",
        "label": "4"
      },
      {
        "url": "/jewels/p4-5.jpg",
        "label": "6"
      }
    ],
    "image": "/jewels/p4-0.jpg",
    "sku": "LA-P4-01",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/larimar-earrings-darla",
    "materialEn": "Sterling silver 925",
    "settingEn": "Closed silver back",
    "includesEn": "Earrings · confirm packaging"
  },
  "p5": {
    "material": "Oro vermeil sobre plata 925 · quilataje por confirmar",
    "weight": "≈ 23 g",
    "dimensions": "Piedras marqués: 15 × 8 × 7 mm; redondas: 8 × 6 mm",
    "setting": "Reverso cerrado en plata",
    "includes": "Pulsera · una pieza",
    "stone": "Larimar",
    "gallery": [
      {
        "url": "/jewels/p5-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/p5-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/p5-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/p5-4.jpg",
        "label": "5"
      },
      {
        "url": "/jewels/p5-5.jpg",
        "label": "6"
      }
    ],
    "image": "/jewels/p5-0.jpg",
    "sku": "LA-P5-01",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/solara-larimar-bracelet-gold-vermeil",
    "materialEn": "Gold vermeil over sterling silver · fineness to be confirmed",
    "dimensionsEn": "Marquise stones: 15 × 8 × 7 mm; round: 8 × 6 mm",
    "settingEn": "Closed silver back",
    "includesEn": "Bracelet · one piece"
  }
};
