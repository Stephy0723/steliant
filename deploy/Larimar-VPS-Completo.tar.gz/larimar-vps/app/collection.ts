export const archiveCollection:any[] = [
  {
    "id": "archive-1",
    "kind": "product",
    "name": "Giselle",
    "en": "Giselle",
    "category": "Anillos",
    "price": 16700,
    "stock": 3,
    "image": "/jewels/archive-1-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-1-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-1-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-1-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-1-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Plata 925",
    "materialEn": "Sterling silver 925",
    "metalGroup": "silver",
    "weight": "10 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-001",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/larimar-ring-giselle"
  },
  {
    "id": "archive-2",
    "kind": "product",
    "name": "Eterna Band Vermeil",
    "en": "Eterna Band Vermeil",
    "category": "Anillos",
    "price": 22700,
    "stock": 4,
    "image": "/jewels/archive-2-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-2-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-2-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-2-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-2-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Oro vermeil · ley por confirmar",
    "materialEn": "Gold vermeil · fineness to confirm",
    "metalGroup": "gold",
    "weight": "9 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-002",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/larimar-gold-vermeil-eterna-ring-band"
  },
  {
    "id": "archive-3",
    "kind": "product",
    "name": "Gabi",
    "en": "Gabi",
    "category": "Anillos",
    "price": 29900,
    "stock": 5,
    "image": "/jewels/archive-3-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-3-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-3-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-3-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-3-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Plata 925",
    "materialEn": "Sterling silver 925",
    "metalGroup": "silver",
    "weight": "31 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-003",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/rough-larimar-ring-gabi"
  },
  {
    "id": "archive-4",
    "kind": "product",
    "name": "Vermeil Vivia",
    "en": "Vermeil Vivia",
    "category": "Anillos",
    "price": 22700,
    "stock": 6,
    "image": "/jewels/archive-4-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-4-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-4-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-4-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-4-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Oro vermeil · ley por confirmar",
    "materialEn": "Gold vermeil · fineness to confirm",
    "metalGroup": "gold",
    "weight": "11 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-004",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/gold-vermeil-larimar-earrings-vivia"
  },
  {
    "id": "archive-5",
    "kind": "product",
    "name": "Giada",
    "en": "Giada",
    "category": "Anillos",
    "price": 16700,
    "stock": 7,
    "image": "/jewels/archive-5-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-5-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-5-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-5-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-5-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Plata 925",
    "materialEn": "Sterling silver 925",
    "metalGroup": "silver",
    "weight": "10 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-005",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/larimar-ring-giada"
  },
  {
    "id": "archive-6",
    "kind": "product",
    "name": "Maris",
    "en": "Maris",
    "category": "Collares",
    "price": 14900,
    "stock": 3,
    "image": "/jewels/archive-6-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-6-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-6-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-6-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-6-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Metal por confirmar",
    "materialEn": "Metal to be confirmed",
    "metalGroup": "other",
    "weight": "8 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "Cadena no incluida",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-006",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/larimar-pendant-maris"
  },
  {
    "id": "archive-7",
    "kind": "product",
    "name": "Marigold",
    "en": "Marigold",
    "category": "Collares",
    "price": 19700,
    "stock": 4,
    "image": "/jewels/archive-7-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-7-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-7-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-7-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-7-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Oro vermeil · ley por confirmar",
    "materialEn": "Gold vermeil · fineness to confirm",
    "metalGroup": "gold",
    "weight": "9 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "Cadena no incluida",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-007",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/gold-vermeil-larimar-pendant-marigold"
  },
  {
    "id": "archive-8",
    "kind": "product",
    "name": "Mirabelle",
    "en": "Mirabelle",
    "category": "Collares",
    "price": 13700,
    "stock": 5,
    "image": "/jewels/archive-8-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-8-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-8-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-8-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-8-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Metal por confirmar",
    "materialEn": "Metal to be confirmed",
    "metalGroup": "other",
    "weight": "7 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "Cadena no incluida",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-008",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/larimar-pendant-mirabelle"
  },
  {
    "id": "archive-9",
    "kind": "product",
    "name": "Gianna",
    "en": "Gianna",
    "category": "Collares",
    "price": 23900,
    "stock": 6,
    "image": "/jewels/archive-9-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-9-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-9-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-9-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-9-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Oro vermeil · ley por confirmar",
    "materialEn": "Gold vermeil · fineness to confirm",
    "metalGroup": "gold",
    "weight": "13 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "Cadena no incluida",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-009",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/gold-vermeil-larimar-pendant-gianna"
  },
  {
    "id": "archive-10",
    "kind": "product",
    "name": "Maude",
    "en": "Maude",
    "category": "Collares",
    "price": 17900,
    "stock": 7,
    "image": "/jewels/archive-10-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-10-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-10-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-10-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-10-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Metal por confirmar",
    "materialEn": "Metal to be confirmed",
    "metalGroup": "other",
    "weight": "11 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "Cadena no incluida",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-010",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/larimar-pendant-maude"
  },
  {
    "id": "archive-11",
    "kind": "product",
    "name": "Marfa",
    "en": "Marfa",
    "category": "Collares",
    "price": 29900,
    "stock": 3,
    "image": "/jewels/archive-11-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-11-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-11-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-11-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-11-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Oro vermeil · ley por confirmar",
    "materialEn": "Gold vermeil · fineness to confirm",
    "metalGroup": "gold",
    "weight": "19 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "Cadena no incluida",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-011",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/gold-vermeil-larimar-pendant-marfa"
  },
  {
    "id": "archive-13",
    "kind": "product",
    "name": "Vermeil Vivia",
    "en": "Vermeil Vivia",
    "category": "Aretes",
    "price": 22700,
    "stock": 5,
    "image": "/jewels/archive-13-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-13-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-13-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-13-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-13-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Oro vermeil · ley por confirmar",
    "materialEn": "Gold vermeil · fineness to confirm",
    "metalGroup": "gold",
    "weight": "11 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-013",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/gold-vermeil-larimar-earrings-vivia"
  },
  {
    "id": "archive-14",
    "kind": "product",
    "name": "Darcy",
    "en": "Darcy",
    "category": "Aretes",
    "price": 16100,
    "stock": 6,
    "image": "/jewels/archive-14-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-14-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-14-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-14-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-14-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Plata 925",
    "materialEn": "Sterling silver 925",
    "metalGroup": "silver",
    "weight": "8 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-014",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/larimar-earrings-darcy"
  },
  {
    "id": "archive-15",
    "kind": "product",
    "name": "Vermeil Vera",
    "en": "Vermeil Vera",
    "category": "Aretes",
    "price": 17900,
    "stock": 7,
    "image": "/jewels/archive-15-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-15-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-15-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-15-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-15-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Oro vermeil · ley por confirmar",
    "materialEn": "Gold vermeil · fineness to confirm",
    "metalGroup": "gold",
    "weight": "5 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-015",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/gold-vermeil-larimar-earrings-vera"
  },
  {
    "id": "archive-16",
    "kind": "product",
    "name": "Dottie",
    "en": "Dottie",
    "category": "Pulseras",
    "price": 16700,
    "stock": 3,
    "image": "/jewels/archive-16-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-16-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-16-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-16-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-16-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Plata 925",
    "materialEn": "Sterling silver 925",
    "metalGroup": "silver",
    "weight": "10 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-016",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/larimar-bracelet-dottie"
  },
  {
    "id": "archive-18",
    "kind": "product",
    "name": "Heart Della",
    "en": "Heart Della",
    "category": "Pulseras",
    "price": 17300,
    "stock": 5,
    "image": "/jewels/archive-18-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-18-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-18-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-18-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-18-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Plata 925",
    "materialEn": "Sterling silver 925",
    "metalGroup": "silver",
    "weight": "11 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-018",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/larimar-heart-bracelet-della"
  },
  {
    "id": "archive-19",
    "kind": "product",
    "name": "Isola",
    "en": "Isola",
    "category": "Pulseras",
    "price": 40700,
    "stock": 6,
    "image": "/jewels/archive-19-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-19-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-19-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-19-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-19-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Oro vermeil · ley por confirmar",
    "materialEn": "Gold vermeil · fineness to confirm",
    "metalGroup": "gold",
    "weight": "29 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-019",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/isola-larimar-bracelet-gold-vermeil"
  },
  {
    "id": "archive-20",
    "kind": "product",
    "name": "Natalie",
    "en": "Natalie",
    "category": "Brazaletes",
    "price": 27500,
    "stock": 7,
    "image": "/jewels/archive-20-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-20-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-20-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-20-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-20-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Plata 925",
    "materialEn": "Sterling silver 925",
    "metalGroup": "silver",
    "weight": "26 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-020",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/larimar-cuff-bracelet-natalie"
  },
  {
    "id": "archive-21",
    "kind": "product",
    "name": "Liv",
    "en": "Liv",
    "category": "Brazaletes",
    "price": 45500,
    "stock": 3,
    "image": "/jewels/archive-21-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-21-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-21-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-21-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-21-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Oro vermeil · ley por confirmar",
    "materialEn": "Gold vermeil · fineness to confirm",
    "metalGroup": "gold",
    "weight": "29 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-021",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/larimar-gold-vermeil-cuff-liv"
  },
  {
    "id": "archive-22",
    "kind": "product",
    "name": "Yindra",
    "en": "Yindra",
    "category": "Brazaletes",
    "price": 29900,
    "stock": 4,
    "image": "/jewels/archive-22-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-22-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-22-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-22-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-22-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Plata 925",
    "materialEn": "Sterling silver 925",
    "metalGroup": "silver",
    "weight": "26 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-022",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/larimar-stone-cuff-bracelet-yindra"
  },
  {
    "id": "archive-23",
    "kind": "product",
    "name": "Mandy",
    "en": "Mandy",
    "category": "Brazaletes",
    "price": 38900,
    "stock": 5,
    "image": "/jewels/archive-23-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-23-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-23-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-23-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-23-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Oro vermeil · ley por confirmar",
    "materialEn": "Gold vermeil · fineness to confirm",
    "metalGroup": "gold",
    "weight": "24 g",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-023",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/larimar-vermeil-cuff-mandy"
  },
  {
    "id": "archive-24",
    "kind": "product",
    "name": "Celestial",
    "en": "Celestial",
    "category": "Conjuntos",
    "price": 13700,
    "stock": 6,
    "image": "/jewels/archive-24-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-24-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-24-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-24-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-24-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Plata 925",
    "materialEn": "Sterling silver 925",
    "metalGroup": "silver",
    "weight": "",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-024",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/larimar-stud-set-celestial"
  },
  {
    "id": "archive-25",
    "kind": "product",
    "name": "Stellar",
    "en": "Stellar",
    "category": "Conjuntos",
    "price": 13700,
    "stock": 7,
    "image": "/jewels/archive-25-0.jpg",
    "gallery": [
      {
        "url": "/jewels/archive-25-0.jpg",
        "label": "1"
      },
      {
        "url": "/jewels/archive-25-1.jpg",
        "label": "2"
      },
      {
        "url": "/jewels/archive-25-2.jpg",
        "label": "3"
      },
      {
        "url": "/jewels/archive-25-3.jpg",
        "label": "4"
      }
    ],
    "stone": "Larimar",
    "material": "Plata 925",
    "materialEn": "Sterling silver 925",
    "metalGroup": "silver",
    "weight": "",
    "dimensions": "",
    "size": "",
    "finish": "",
    "chain": "",
    "description": "Una pieza de referencia de Larimar. Explora sus ángulos y confirma con el atelier las especificaciones de tu pieza.",
    "descriptionEn": "A Larimar reference piece. Explore its angles and confirm the specifications of your piece with the atelier.",
    "sku": "LA-ARCH-025",
    "reference": true,
    "specVersion": 1,
    "sourceUrl": "https://thelarimarshop.com/products/larimar-studs-set-stellar"
  }
];
