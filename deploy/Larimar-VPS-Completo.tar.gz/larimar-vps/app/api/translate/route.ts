import {sameOrigin} from '../../access';
import {env} from 'cloudflare:workers';
import {getActor} from '../../access';
import {publicRecord} from '../../public-data';
import {missingTranslations,put} from '../../translation-fields';
import {translateText} from '../../translation-service';
export async function POST(req:Request){if(!sameOrigin(req))return Response.json({error:'Origen no permitido'},{status:403});
 const actor=await getActor();
 try{const x:any=await req.json();if(typeof x.id!=='string')throw Error('Registro inválido');const r:any=await env.DB!.prepare('SELECT data FROM records WHERE id=?').bind(x.id).first();if(!r)throw Error('Registro no encontrado');const record=JSON.parse(r.data);if(!actor&&(record.kind==='product'&&record.published===false||['collection','promotion'].includes(record.kind)&&!record.active))return Response.json({error:'No encontrado'},{status:404});if(!['product','settings','promotion','collection'].includes(record.kind))return Response.json({error:'Solo se traduce el contenido de la tienda'},{status:400});
 const result=structuredClone(record);let completed=0,failed=false;for(const pair of missingTranslations(record).slice(0,12)){try{const translation=await translateText(pair.text,env.DB!);put(result,pair.target,translation);result._autoTranslationSources={...(result._autoTranslationSources||{}),[pair.target]:pair.text};completed++}catch{failed=true;break}}
 if(completed)await env.DB!.prepare('UPDATE records SET data=? WHERE id=? AND data=?').bind(JSON.stringify(result),record.id,r.data).run();
 const latest:any=await env.DB!.prepare('SELECT data FROM records WHERE id=?').bind(record.id).first();const saved=latest?JSON.parse(latest.data):result;
 return Response.json({record:publicRecord(saved),completed,pending:missingTranslations(saved).length,status:failed?'unavailable':missingTranslations(saved).length?'partial':'ready'});
 }catch(e:any){return Response.json({error:e.message||'No se pudo traducir'},{status:400})}
}
