import {env} from 'cloudflare:workers';
import {expireReservations} from '../../reservations';
import {publicRecord} from '../../public-data';
export async function GET(){await expireReservations(env.DB!);const r=await env.DB!.prepare("SELECT data FROM records WHERE kind IN ('product','settings','promotion','collection','social')").all();return Response.json((r.results as any[]).map(x=>JSON.parse(x.data)).filter(r=>(r.kind!=='product'||r.published!==false)&&(r.kind!=='social'||r.visible)).map(publicRecord),{headers:{'Cache-Control':'no-store'}})}
