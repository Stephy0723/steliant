import {getActor} from '../../access';
export async function GET(){const actor=await getActor();return Response.json({role:actor?.role||null,name:actor?.displayName||'',email:actor?.email||''},{headers:{'Cache-Control':'no-store'}})}
