export type TranslationPair={source:string,target:string,text:string};
export function at(object:any,path:string){return path.split('.').reduce((value,key)=>value?.[key],object)}
export function put(object:any,path:string,value:any){const keys=path.split('.');let node=object;for(const key of keys.slice(0,-1)){if(!node[key]||typeof node[key]!=='object')node[key]={};node=node[key]}node[keys[keys.length-1]]=value}
export function erase(object:any,path:string){const keys=path.split('.');let node=object;for(const key of keys.slice(0,-1)){if(!node?.[key])return;node=node[key]}delete node[keys[keys.length-1]]}
export function publicTranslationPairs(record:any):TranslationPair[]{
 const fields:[string,string][]=[];
 if(record.kind==='product'){fields.push(['name','en'],['description','descriptionEn']);for(const key of ['material','stone','weight','dimensions','size','finish','setting','chain','includes'])fields.push([key,key+'En'])}
 if(record.kind==='promotion'||record.kind==='collection')fields.push(['name','nameEn'],['description','descriptionEn']);
 if(record.kind==='settings'){
 fields.push(['tagline','taglineEn'],['notice','noticeEn'],['deliveryPolicy','deliveryPolicyEn'],['returnPolicy','returnPolicyEn'],['privacyPolicy','privacyPolicyEn'],['content.storyTitle','content.storyTitleEn'],['content.storyBody','content.storyBodyEn']);
 for(const key of ['heroTitle','heroItalic','heroCaption','hero2Title','hero2Italic','hero3Title','hero3Italic','categoryTitle','featuredTitle','featuredItalic','editorialTitle','editorialItalic','editorialText','reservationTitle','reservationText','footerTitle','footerItalic','footerText'])fields.push(['content.'+key,'content.en.'+key]);
 }
 return fields.map(([source,target])=>({source,target,text:at(record,source)})).filter(p=>typeof p.text==='string'&&p.text.trim().length>0);
}
export function missingTranslations(record:any){return publicTranslationPairs(record).filter(p=>!at(record,p.target)||record._autoTranslationSources?.[p.target]&&record._autoTranslationSources[p.target]!==p.text)}
export function invalidateTranslations(next:any,previous:any){const result=structuredClone(next);const sources={...(previous?._autoTranslationSources||{})};const pairs=new Map([...publicTranslationPairs(previous||{}),...publicTranslationPairs(result)].map(p=>[p.target,p]));for(const pair of pairs.values()){const source=at(result,pair.source);if(!previous||at(previous,pair.source)!==source){erase(result,pair.target);delete sources[pair.target]}}result._autoTranslationSources=sources;return result}
export function mergePublicTranslations(current:any,translated:any){const result=structuredClone(current);for(const pair of publicTranslationPairs(current)){const text=at(translated,pair.target);if(at(translated,pair.source)===pair.text&&typeof text==='string'&&text){put(result,pair.target,text);result._autoTranslationSources={...(result._autoTranslationSources||{}),[pair.target]:pair.text}}}return result}
