import type { Metadata } from 'next';
import './globals.css';
import './boutique.css';
import './atelier-nav.css';
import './atelier-footer.css';
import './business-crm.css';
import './checkout.css';
export const metadata:Metadata={title:'Larimar Atelier | El Caribe, hecho joya',description:'Una colección de joyas inspiradas en el azul del Caribe.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="es"><body>{children}</body></html>}
