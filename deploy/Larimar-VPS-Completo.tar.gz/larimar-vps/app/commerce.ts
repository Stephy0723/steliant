export const channels=['Web','Local','WhatsApp','Instagram','Facebook','TikTok','Otro'];
export const seasons=['Verano','Invierno','Primavera','Otoño','Todo el año'];
export function activePromotion(p:any,now=Date.now()){
 if(!p.active)return false;
 if(p.start&&now<new Date(p.start+'T00:00:00-04:00').getTime())return false;
 if(p.end&&now>new Date(p.end+'T23:59:59-04:00').getTime())return false;
 return true;
}
export function salePrice(product:any,promotions:any[]=[],now=Date.now()){
 const base=Number(product.price||0);let price=base,label='',labelEn='';
 for(const p of promotions){if(!activePromotion(p,now))continue;const match=p.scope==='all'||(p.scope==='category'&&p.category===product.category)||(p.scope==='season'&&(product.seasons||[]).includes(p.season))||(p.scope==='products'&&(p.productIds||[]).includes(product.id));if(!match)continue;const next=p.type==='percent'?base*(1-Number(p.value)/100):Number(p.value);if(next>=0&&next<price){price=Math.round(next*100)/100;label=p.name;labelEn=p.nameEn||p.name}}
 return {price,label,labelEn};
}
export function withSeasons(p:any,records:any[]){const extra=records.filter(r=>r.kind==='collection'&&r.active&&(r.productIds||[]).includes(p.id)&&r.season).map(r=>r.season);return {...p,seasons:Array.from(new Set([...(p.seasons||[]),...extra]))}}
export function merchandise(products:any[],records:any[],now=Date.now()){
 const promos=records.filter(r=>r.kind==='promotion');return products.filter(p=>p.published!==false).map(raw=>{const p=withSeasons(raw,records);const s=salePrice(p,promos,now);return {...p,basePrice:Number(p.price),price:s.price,specialLabel:s.label,specialLabelEn:s.labelEn,isSpecial:s.price<Number(p.price)}})
}
export function businessMetrics(orders:any[],records:any[],period:{start?:string,end?:string}={}){
 const inPeriod=(r:any)=>{const d=businessDay(r.date||'');return (!period.start||d>=period.start)&&(!period.end||d<=period.end)};
 const live=orders.filter(o=>o.confirmed!==false&&!['Cancelado','Vencido'].includes(o.status));const sold=live.filter(o=>inPeriod({...o,date:o.confirmedAt||o.date}));
 const returns=records.filter(r=>r.kind==='return'&&inPeriod(r));const returned=returns.reduce((s,r)=>s+Number(r.amount||0),0);
 const gross=sold.reduce((s,o)=>s+Number(o.total||0),0)-returned;
 const payments=records.filter(r=>r.kind==='payment'&&inPeriod(r));const collected=payments.reduce((s,r)=>s+Number(r.amount||0),0);
 const refunds=records.filter(r=>r.kind==='refund'&&inPeriod(r)).reduce((s,r)=>s+Number(r.amount||0),0);
 const reversedCost=returns.reduce((s,r)=>s+(r.items||[]).reduce((n:number,i:any)=>n+(i.restock?Number(i.cost||0)*i.qty:0),0),0);
 const cogs=sold.reduce((s,o)=>s+(o.items||[]).reduce((x:number,i:any)=>x+Number(i.cost||0)*Number(i.qty),0),0)-reversedCost;
 const missingCost=sold.filter(o=>(o.items||[]).some((i:any)=>i.cost===null||i.cost===undefined)).length;
 const expenses=records.filter(r=>r.kind==='expense'&&!r.voided&&inPeriod(r)).reduce((s,r)=>s+Number(r.amount||0),0),losses=records.filter(r=>r.kind==='loss'&&inPeriod(r)).reduce((s,r)=>s+Number(r.amount||0),0),supplierPaid=records.filter(r=>r.kind==='supplierpayment'&&inPeriod(r)).reduce((s,r)=>s+Number(r.amount||0),0);
 const balance=live.reduce((s,o)=>s+Math.max(0,Number(o.total)-Number(o.returnedValue||0)-Number(o.paid||0)+Number(o.refunded||0)),0);
 return {gross,collected,refunds,returned,cogs,missingCost,expenses,losses,balance,result:gross-cogs-expenses-losses,cash:collected-refunds-expenses-supplierPaid,supplierPaid};
}
export function businessDay(value:string){if(!value)return '';if(/^\d{4}-\d{2}-\d{2}$/.test(value))return value;const d=new Date(value);if(!Number.isFinite(d.getTime()))return '';const parts=new Intl.DateTimeFormat('en',{timeZone:'America/Santo_Domingo',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(d);const get=(type:string)=>parts.find(p=>p.type===type)?.value||'';return `${get('year')}-${get('month')}-${get('day')}`}
