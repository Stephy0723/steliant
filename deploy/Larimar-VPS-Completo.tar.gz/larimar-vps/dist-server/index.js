import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { Readable } from "node:stream";
import { AsyncLocalStorage } from "node:async_hooks";
import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { DatabaseSync } from "node:sqlite";
//#region \0rolldown/runtime.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
//#endregion
//#region server/storage.mjs
var dataDir = path.resolve(process.env.DATA_DIR || "./data");
fs.mkdirSync(dataDir, {
	recursive: true,
	mode: 448
});
var sql = new DatabaseSync(path.join(dataDir, "larimar.sqlite"));
sql.exec("PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS records(id TEXT PRIMARY KEY,kind TEXT NOT NULL,data TEXT NOT NULL);CREATE TABLE IF NOT EXISTS users(email TEXT PRIMARY KEY,salt TEXT NOT NULL,hash TEXT NOT NULL);CREATE TABLE IF NOT EXISTS sessions(hash TEXT PRIMARY KEY,email TEXT NOT NULL,expires INTEGER NOT NULL);");
var Query = class {
	constructor(text) {
		this.text = text;
		this.values = [];
	}
	bind(...values) {
		this.values = values;
		return this;
	}
	async first() {
		return sql.prepare(this.text).get(...this.values) || null;
	}
	async all() {
		return { results: sql.prepare(this.text).all(...this.values) };
	}
	async run() {
		return sql.prepare(this.text).run(...this.values);
	}
};
var DB = {
	prepare: (text) => new Query(text),
	async batch(queries) {
		sql.exec("BEGIN IMMEDIATE");
		try {
			const result = [];
			for (const q of queries) result.push(sql.prepare(q.text).run(...q.values));
			sql.exec("COMMIT");
			return result;
		} catch (e) {
			sql.exec("ROLLBACK");
			throw e;
		}
	}
};
var bucket = path.join(dataDir, "files");
fs.mkdirSync(bucket, {
	recursive: true,
	mode: 448
});
function resolveKey(key) {
	if (typeof key !== "string" || !/^[a-zA-Z0-9/_\-.]+$/.test(key) || key.includes("..")) throw Error("Clave inválida");
	const full = path.resolve(bucket, key);
	if (!full.startsWith(bucket + path.sep)) throw Error("Clave inválida");
	return full;
}
var env = {
	DB,
	BUCKET: {
		async put(key, bytes, meta) {
			const file = resolveKey(key);
			fs.mkdirSync(path.dirname(file), { recursive: true });
			const data = typeof bytes === "string" ? Buffer.from(bytes) : Buffer.from(bytes instanceof ArrayBuffer ? new Uint8Array(bytes) : bytes);
			fs.writeFileSync(file, data, { mode: 384 });
			fs.writeFileSync(file + ".meta", JSON.stringify(meta || {}), { mode: 384 });
		},
		async get(key) {
			const file = resolveKey(key);
			if (!fs.existsSync(file)) return null;
			const bytes = fs.readFileSync(file);
			let meta = {};
			try {
				meta = JSON.parse(fs.readFileSync(file + ".meta", "utf8"));
			} catch {}
			return {
				body: bytes,
				httpMetadata: meta.httpMetadata || {},
				text: async () => bytes.toString(),
				arrayBuffer: async () => bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength)
			};
		}
	}
};
//#endregion
//#region server/auth.mjs
var context = new AsyncLocalStorage();
var ownerEmail = String(process.env.OWNER_EMAIL || "steliantsoft@gmail.com").toLowerCase();
var digest = (x) => createHash("sha256").update(x).digest("hex");
function getChatGPTUser() {
	return Promise.resolve(context.getStore() || null);
}
function setPassword(email, password) {
	if (typeof password !== "string" || password.length < 12 || password.length > 200) throw Error("Usa una contraseña de 12 a 200 caracteres");
	const salt = randomBytes(16).toString("hex"), hash = scryptSync(password, salt, 64).toString("hex");
	sql.prepare("INSERT INTO users(email,salt,hash) VALUES(?,?,?) ON CONFLICT(email) DO UPDATE SET salt=excluded.salt,hash=excluded.hash").run(email.toLowerCase(), salt, hash);
	sql.prepare("DELETE FROM sessions WHERE email=?").run(email.toLowerCase());
}
function verify(email, password) {
	const r = sql.prepare("SELECT * FROM users WHERE email=?").get(email);
	const test = scryptSync(password, r?.salt || "00000000000000000000000000000000", 64);
	return !!r && timingSafeEqual(test, Buffer.from(r.hash, "hex"));
}
function identity(req) {
	const cookie = String(req.headers.cookie || "").split(";").map((s) => s.trim()).find((s) => s.startsWith("larimar_session="));
	if (!cookie) return null;
	const token = cookie.slice(16);
	const r = sql.prepare("SELECT email FROM sessions WHERE hash=? AND expires>?").get(digest(token), Date.now());
	if (!r) return null;
	if (r.email !== ownerEmail) {
		if (!sql.prepare("SELECT data FROM records WHERE kind='staff'").all().map((r) => JSON.parse(r.data)).some((s) => s.email === r.email && s.active)) return null;
	}
	return {
		userId: digest(r.email),
		email: r.email,
		displayName: r.email
	};
}
function createSession(email) {
	const token = randomBytes(32).toString("hex");
	sql.prepare("DELETE FROM sessions WHERE expires<?").run(Date.now());
	sql.prepare("INSERT INTO sessions(hash,email,expires) VALUES(?,?,?)").run(digest(token), email, Date.now() + 12 * 36e5);
	return token;
}
//#endregion
//#region .generated/app/public-data.ts
function publicRecord(r) {
	if (r.kind === "product") return Object.fromEntries([
		"id",
		"kind",
		"name",
		"en",
		"category",
		"sku",
		"price",
		"stock",
		"image",
		"gallery",
		"description",
		"descriptionEn",
		"material",
		"stone",
		"weight",
		"dimensions",
		"size",
		"finish",
		"setting",
		"chain",
		"includes",
		"metalGroup",
		"body",
		"published",
		"isNew",
		"reference",
		"seasons",
		"specVersion",
		"materialEn",
		"stoneEn",
		"weightEn",
		"dimensionsEn",
		"sizeEn",
		"finishEn",
		"settingEn",
		"chainEn",
		"includesEn"
	].filter((k) => r[k] !== void 0).map((k) => [k, r[k]]));
	if (r.kind === "settings") {
		const out = Object.fromEntries([
			"id",
			"kind",
			"brand",
			"tagline",
			"taglineEn",
			"notice",
			"noticeEn",
			"rate",
			"deposit",
			"shipping",
			"taxRate",
			"taxIncluded",
			"address",
			"catalogSeedVersion",
			"content",
			"phone",
			"email",
			"hours",
			"deliveryPolicy",
			"returnPolicy",
			"privacyPolicy",
			"deliveryPolicyEn",
			"returnPolicyEn",
			"privacyPolicyEn",
			"reservationHours"
		].filter((k) => r[k] !== void 0).map((k) => [k, r[k]]));
		if (out.content) {
			out.content = { ...out.content };
			delete out.content.adminCoverImage;
		}
		return out;
	}
	return r;
}
function specifications(p) {
	return Object.fromEntries([
		"sku",
		"material",
		"size",
		"dimensions",
		"weight",
		"chain",
		"finish",
		"setting",
		"includes",
		"stone",
		"materialEn",
		"sizeEn",
		"dimensionsEn",
		"weightEn",
		"chainEn",
		"finishEn",
		"settingEn",
		"includesEn",
		"stoneEn"
	].map((k) => [k, p[k] || ""]));
}
function specFingerprint(p) {
	return JSON.stringify([
		p.material || "",
		p.size || "",
		p.dimensions || "",
		p.weight || "",
		p.chain || "",
		p.finish || "",
		p.setting || "",
		p.includes || "",
		p.stone || ""
	]);
}
function customerOrder(o) {
	return {
		...Object.fromEntries([
			"id",
			"date",
			"name",
			"email",
			"phone",
			"address",
			"delivery",
			"reserve",
			"total",
			"shipping",
			"subtotal",
			"tax",
			"taxRate",
			"taxIncluded",
			"due",
			"paid",
			"refunded",
			"returnedValue",
			"status",
			"expiresAt",
			"confirmed",
			"currency",
			"exchangeRate"
		].map((k) => [k, o[k]])),
		items: (o.items || []).map((i) => ({
			id: i.id,
			name: i.name,
			qty: i.qty,
			price: i.price,
			specifications: i.specifications
		}))
	};
}
//#endregion
//#region .generated/app/commerce.ts
function activePromotion(p, now = Date.now()) {
	if (!p.active) return false;
	if (p.start && now < (/* @__PURE__ */ new Date(p.start + "T00:00:00-04:00")).getTime()) return false;
	if (p.end && now > (/* @__PURE__ */ new Date(p.end + "T23:59:59-04:00")).getTime()) return false;
	return true;
}
function salePrice(product, promotions = [], now = Date.now()) {
	const base = Number(product.price || 0);
	let price = base, label = "", labelEn = "";
	for (const p of promotions) {
		if (!activePromotion(p, now)) continue;
		if (!(p.scope === "all" || p.scope === "category" && p.category === product.category || p.scope === "season" && (product.seasons || []).includes(p.season) || p.scope === "products" && (p.productIds || []).includes(product.id))) continue;
		const next = p.type === "percent" ? base * (1 - Number(p.value) / 100) : Number(p.value);
		if (next >= 0 && next < price) {
			price = Math.round(next * 100) / 100;
			label = p.name;
			labelEn = p.nameEn || p.name;
		}
	}
	return {
		price,
		label,
		labelEn
	};
}
function withSeasons(p, records) {
	const extra = records.filter((r) => r.kind === "collection" && r.active && (r.productIds || []).includes(p.id) && r.season).map((r) => r.season);
	return {
		...p,
		seasons: Array.from(new Set([...p.seasons || [], ...extra]))
	};
}
function businessDay(value) {
	if (!value) return "";
	if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
	const d = new Date(value);
	if (!Number.isFinite(d.getTime())) return "";
	const parts = new Intl.DateTimeFormat("en", {
		timeZone: "America/Santo_Domingo",
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).formatToParts(d);
	const get = (type) => parts.find((p) => p.type === type)?.value || "";
	return `${get("year")}-${get("month")}-${get("day")}`;
}
//#endregion
//#region .generated/app/access.ts
function sameOrigin(req) {
	const origin = req.headers.get("origin");
	return !origin || origin === new URL(req.url).origin;
}
var OWNER_EMAIL = String(process.env.OWNER_EMAIL || "steliantsoft@gmail.com").toLowerCase();
async function getActor() {
	const u = await getChatGPTUser();
	if (!u) return null;
	if (u.email?.toLowerCase() === OWNER_EMAIL) return {
		...u,
		role: "owner"
	};
	const member = (await env.DB.prepare("SELECT data FROM records WHERE kind='staff'").all()).results.map((x) => JSON.parse(x.data)).find((x) => x.email?.toLowerCase() === u.email?.toLowerCase() && x.active);
	return member && ["sales", "inventory"].includes(member.role) ? {
		...u,
		role: member.role
	} : null;
}
function permits(actor, area) {
	return !!actor && (actor.role === "owner" || actor.role === "sales" && [
		"sales",
		"customer",
		"inquiry",
		"delivery"
	].includes(area) || actor.role === "inventory" && [
		"inventory",
		"product",
		"supplier"
	].includes(area));
}
function readable(records, actor) {
	if (actor?.role === "owner") return records;
	const kinds = actor?.role === "sales" ? [
		"settings",
		"product",
		"order",
		"payment",
		"return",
		"refund",
		"customer",
		"inquiry",
		"delivery",
		"courier",
		"notification"
	] : [
		"settings",
		"product",
		"supplier",
		"purchase",
		"loss",
		"stockmovement"
	];
	return records.filter((r) => kinds.includes(r.kind)).map((r) => {
		if (r.kind === "settings") return publicRecord(r);
		if (actor?.role === "sales" && r.kind === "product") {
			const { cost, supplierId, ...p } = r;
			return p;
		}
		if (actor?.role === "sales" && ["order", "return"].includes(r.kind)) return {
			...r,
			items: (r.items || []).map((i) => {
				const { cost, ...p } = i;
				return p;
			})
		};
		return r;
	});
}
function audit(actor, action, target, detail = {}) {
	return {
		id: crypto.randomUUID(),
		kind: "audit",
		date: (/* @__PURE__ */ new Date()).toISOString(),
		actor: actor?.email || "Visitante",
		action,
		target,
		detail
	};
}
async function snapshot(db, bucket, label = "Automático antes de cambios", force = false) {
	const day = businessDay((/* @__PURE__ */ new Date()).toISOString()), id = force ? "backup-" + crypto.randomUUID() : "backup-daily-" + day;
	if (await db.prepare("SELECT id FROM records WHERE id=?").bind(id).first()) return null;
	const rows = (await db.prepare("SELECT id,kind,data FROM records WHERE kind NOT IN ('backup','ratelimit','translation','guard')").all()).results;
	const key = "backups/" + id + ".json";
	await bucket.put(key, JSON.stringify({
		format: "larimar-backup-v1",
		createdAt: (/* @__PURE__ */ new Date()).toISOString(),
		rows
	}), { httpMetadata: { contentType: "application/json" } });
	const b = {
		id,
		kind: "backup",
		date: (/* @__PURE__ */ new Date()).toISOString(),
		label,
		key,
		count: rows.length
	};
	await db.prepare("INSERT OR IGNORE INTO records(id,kind,data) VALUES(?,?,?)").bind(id, "backup", JSON.stringify(b)).run();
	return b;
}
//#endregion
//#region .generated/app/reservations.ts
async function expireReservations(db) {
	const rows = (await db.prepare("SELECT id,data FROM records WHERE kind='order'").all()).results;
	for (const r of rows) {
		const o = JSON.parse(r.data);
		if (!o.stockBooked || !o.expiresAt || new Date(o.expiresAt).getTime() > Date.now() || Number(o.paid) > 0 || [
			"Cancelado",
			"Vencido",
			"Entregado",
			"Enviado"
		].includes(o.status)) continue;
		const statements = [];
		const guard = (id, data, next) => {
			const g = "guard-" + crypto.randomUUID();
			statements.push(db.prepare("UPDATE records SET data=? WHERE id=? AND data=?").bind(JSON.stringify(next), id, data), db.prepare("INSERT INTO records(id,kind,data) VALUES(?,'guard',CASE WHEN changes()=1 THEN '{}' ELSE NULL END)").bind(g), db.prepare("DELETE FROM records WHERE id=?").bind(g));
		};
		for (const i of o.items) {
			const p = await db.prepare("SELECT data FROM records WHERE id=? AND kind='product'").bind(i.id).first();
			if (p) guard(i.id, p.data, {
				...JSON.parse(p.data),
				stock: Number(JSON.parse(p.data).stock) + Number(i.qty)
			});
		}
		guard(o.id, r.data, {
			...o,
			status: "Vencido",
			stockBooked: false,
			confirmed: false
		});
		const a = {
			id: crypto.randomUUID(),
			kind: "audit",
			date: (/* @__PURE__ */ new Date()).toISOString(),
			actor: "Sistema",
			action: "Reserva vencida y stock liberado",
			target: o.id
		};
		statements.push(db.prepare("INSERT INTO records(id,kind,data) VALUES(?,?,?)").bind(a.id, a.kind, JSON.stringify(a)));
		try {
			await db.batch(statements);
		} catch {}
	}
}
//#endregion
//#region .generated/app/api/shop/route.ts
var route_exports$10 = /* @__PURE__ */ __exportAll({ GET: () => GET$5 });
async function GET$5() {
	await expireReservations(env.DB);
	const r = await env.DB.prepare("SELECT data FROM records WHERE kind IN ('product','settings','promotion','collection','social')").all();
	return Response.json(r.results.map((x) => JSON.parse(x.data)).filter((r) => (r.kind !== "product" || r.published !== false) && (r.kind !== "social" || r.visible)).map(publicRecord), { headers: { "Cache-Control": "no-store" } });
}
//#endregion
//#region .generated/app/api/access/route.ts
var route_exports$9 = /* @__PURE__ */ __exportAll({ GET: () => GET$4 });
async function GET$4() {
	const actor = await getActor();
	return Response.json({
		role: actor?.role || null,
		name: actor?.displayName || "",
		email: actor?.email || ""
	}, { headers: { "Cache-Control": "no-store" } });
}
//#endregion
//#region .generated/app/translation-fields.ts
function at(object, path) {
	return path.split(".").reduce((value, key) => value?.[key], object);
}
function put(object, path, value) {
	const keys = path.split(".");
	let node = object;
	for (const key of keys.slice(0, -1)) {
		if (!node[key] || typeof node[key] !== "object") node[key] = {};
		node = node[key];
	}
	node[keys[keys.length - 1]] = value;
}
function erase(object, path) {
	const keys = path.split(".");
	let node = object;
	for (const key of keys.slice(0, -1)) {
		if (!node?.[key]) return;
		node = node[key];
	}
	delete node[keys[keys.length - 1]];
}
function publicTranslationPairs(record) {
	const fields = [];
	if (record.kind === "product") {
		fields.push(["name", "en"], ["description", "descriptionEn"]);
		for (const key of [
			"material",
			"stone",
			"weight",
			"dimensions",
			"size",
			"finish",
			"setting",
			"chain",
			"includes"
		]) fields.push([key, key + "En"]);
	}
	if (record.kind === "promotion" || record.kind === "collection") fields.push(["name", "nameEn"], ["description", "descriptionEn"]);
	if (record.kind === "settings") {
		fields.push(["tagline", "taglineEn"], ["notice", "noticeEn"], ["deliveryPolicy", "deliveryPolicyEn"], ["returnPolicy", "returnPolicyEn"], ["privacyPolicy", "privacyPolicyEn"], ["content.storyTitle", "content.storyTitleEn"], ["content.storyBody", "content.storyBodyEn"]);
		for (const key of [
			"heroTitle",
			"heroItalic",
			"heroCaption",
			"hero2Title",
			"hero2Italic",
			"hero3Title",
			"hero3Italic",
			"categoryTitle",
			"featuredTitle",
			"featuredItalic",
			"editorialTitle",
			"editorialItalic",
			"editorialText",
			"reservationTitle",
			"reservationText",
			"footerTitle",
			"footerItalic",
			"footerText"
		]) fields.push(["content." + key, "content.en." + key]);
	}
	return fields.map(([source, target]) => ({
		source,
		target,
		text: at(record, source)
	})).filter((p) => typeof p.text === "string" && p.text.trim().length > 0);
}
function missingTranslations(record) {
	return publicTranslationPairs(record).filter((p) => !at(record, p.target) || record._autoTranslationSources?.[p.target] && record._autoTranslationSources[p.target] !== p.text);
}
function invalidateTranslations(next, previous) {
	const result = structuredClone(next);
	const sources = { ...previous?._autoTranslationSources || {} };
	const pairs = new Map([...publicTranslationPairs(previous || {}), ...publicTranslationPairs(result)].map((p) => [p.target, p]));
	for (const pair of pairs.values()) {
		const source = at(result, pair.source);
		if (!previous || at(previous, pair.source) !== source) {
			erase(result, pair.target);
			delete sources[pair.target];
		}
	}
	result._autoTranslationSources = sources;
	return result;
}
//#endregion
//#region .generated/app/api/store/route.ts
var route_exports$8 = /* @__PURE__ */ __exportAll({
	GET: () => GET$3,
	POST: () => POST$6
});
async function GET$3() {
	const actor = await getActor();
	if (!actor) return Response.json({ error: "Acceso administrativo requerido" }, { status: 401 });
	await expireReservations(env.DB);
	const r = await env.DB.prepare("SELECT * FROM records WHERE kind NOT IN ('ratelimit','guard','translation')").all();
	return Response.json(readable(r.results.map((x) => ({
		...JSON.parse(x.data),
		id: x.id,
		kind: x.kind
	})), actor), { headers: { "Cache-Control": "no-store" } });
}
async function POST$6(req) {
	if (!sameOrigin(req)) return Response.json({ error: "Origen no permitido" }, { status: 403 });
	const actor = await getActor();
	if (!actor) return Response.json({ error: "Acceso administrativo requerido" }, { status: 401 });
	try {
		let x = await req.json();
		if (!permits(actor, {
			product: "product",
			supplier: "supplier",
			customer: "customer",
			inquiry: "inquiry",
			delivery: "delivery",
			courier: "delivery",
			notification: "sales"
		}[x.kind] || "owner")) return Response.json({ error: "No tienes permiso para modificar este módulo" }, { status: 403 });
		if (![
			"product",
			"settings",
			"inquiry",
			"expense",
			"supplier",
			"courier",
			"social",
			"collection",
			"promotion",
			"delivery",
			"customer",
			"staff",
			"notification"
		].includes(x.kind) || typeof x.id !== "string" || !x.id || x.id.length > 120 || JSON.stringify(x).length > 2e5) throw Error("Registro inválido");
		const db = env.DB;
		const raw = await db.prepare("SELECT kind,data FROM records WHERE id=?").bind(x.id).first();
		const old = raw ? JSON.parse(raw.data) : null;
		if (raw && raw.kind !== x.kind) throw Error("Identificador usado por otro tipo de registro");
		if (x.kind === "settings" && x.id !== "config") throw Error("Configuración no válida");
		const number = (v) => Number.isFinite(Number(v)) && Number(v) >= 0;
		if (x.action === "delete") {
			if ([
				"expense",
				"settings",
				"staff",
				"inquiry",
				"notification"
			].includes(x.kind)) throw Error("No se puede borrar este registro. Usa anulación, estado o desactivación.");
			x = {
				...old,
				...x.kind === "product" ? { published: false } : {
					active: false,
					archived: true
				},
				id: x.id,
				kind: x.kind
			};
			if (!old) throw Error("Registro no encontrado");
		}
		if (x.kind === "product") {
			if (!x.name?.trim() || !number(x.price) || !number(x.stock) || !Number.isInteger(Number(x.stock))) throw Error("Nombre, precio o stock inválido");
			if (old) x.stock = old.stock;
			if (actor.role === "inventory" && old) x.price = old.price;
			if (!x.image) throw Error("Selecciona una foto");
			x.sku = String(x.sku || old?.sku || x.id).trim();
			if ((await db.prepare("SELECT data FROM records WHERE kind='product'").all()).results.map((r) => JSON.parse(r.data)).some((p) => p.id !== x.id && p.sku === x.sku)) throw Error("Ya existe otra referencia con este SKU");
			if (x.published !== false && !x.reference && (!x.material?.trim() || !x.weight?.trim() || !x.dimensions?.trim() || x.category === "Anillos" && !x.size?.trim() || x.category === "Collares" && !x.chain?.trim())) throw Error("Completa material, peso y medidas con unidades. Los anillos necesitan talla y los collares largo de cadena. Puedes guardar sin publicar.");
		}
		if (x.kind === "expense") {
			if (old) throw Error("Los gastos registrados no se sobrescriben: anula el movimiento y registra la corrección");
			if (!x.name?.trim() || !number(x.amount) || Number(x.amount) <= 0) throw Error("Concepto e importe requeridos");
			x.locked = false;
		}
		if (x.kind === "promotion" && (!number(x.value) || x.type === "percent" && Number(x.value) > 100 || x.start && x.end && x.start > x.end)) throw Error("Descuento o fechas inválidos");
		if (x.kind === "settings" && (!number(x.shipping) || !Number.isFinite(Number(x.rate)) || Number(x.rate) <= 0 || !number(x.taxRate || 0) || Number(x.taxRate || 0) > 100 || !number(x.deposit) || Number(x.deposit) > 100 || !Number.isFinite(Number(x.reservationHours ?? 48)) || Number(x.reservationHours ?? 48) < 1 || Number(x.reservationHours ?? 48) > 720)) throw Error("Revisa tasa, abono, envío y duración de reservas");
		if (x.kind === "staff") {
			if (!/^\S+@\S+\.\S+$/.test(x.email || "") || !["sales", "inventory"].includes(x.role)) throw Error("Correo y rol válidos requeridos");
			x.email = x.email.trim().toLowerCase();
			if ((await db.prepare("SELECT data FROM records WHERE kind='staff'").all()).results.map((r) => JSON.parse(r.data)).some((r) => r.id !== x.id && r.email === x.email)) throw Error("Este correo ya está registrado");
		}
		if (x.kind === "customer" && !x.name?.trim()) throw Error("Nombre del cliente requerido");
		if (x.kind === "inquiry") {
			if (!old) throw Error("Usa el formulario público para enviar consultas");
			x = {
				...old,
				status: [
					"Pendiente",
					"Atendida",
					"Cerrada"
				].includes(x.status) ? x.status : old.status,
				internalNote: String(x.internalNote || "").slice(0, 5e3)
			};
		}
		if (x.kind === "notification") {
			if (!old) throw Error("Notificación no encontrada");
			x = {
				...old,
				read: !!x.read
			};
		}
		if (x.kind === "delivery") {
			if (!x.orderId || !number(x.cost || 0) || !number(x.charged || 0)) throw Error("Revisa entrega e importes");
			const o = await db.prepare("SELECT data FROM records WHERE id=? AND kind='order'").bind(x.orderId).first();
			if (!o || JSON.parse(o.data).confirmed === false || ["Cancelado", "Vencido"].includes(JSON.parse(o.data).status)) throw Error("Confirma el pedido antes de asignar la entrega");
			if (old && old.orderId !== x.orderId && Number(old.paid) > 0) throw Error("Una entrega pagada no se puede mover a otro pedido");
			x.paid = old?.paid || 0;
			if (Number(x.cost) < x.paid) throw Error("El costo no puede ser menor que lo pagado");
		}
		if ([
			"product",
			"settings",
			"promotion",
			"collection"
		].includes(x.kind)) x = invalidateTranslations(x, old);
		delete x.action;
		delete x.formKind;
		await snapshot(db, env.BUCKET);
		const writes = [];
		if (raw) {
			writes.push(db.prepare("UPDATE records SET data=? WHERE id=? AND data=?").bind(JSON.stringify(x), x.id, raw.data));
			const g = "guard-" + crypto.randomUUID();
			writes.push(db.prepare("INSERT INTO records(id,kind,data) VALUES(?,'guard',CASE WHEN changes()=1 THEN '{}' ELSE NULL END)").bind(g), db.prepare("DELETE FROM records WHERE id=?").bind(g));
		} else writes.push(db.prepare("INSERT INTO records(id,kind,data) VALUES(?,?,?)").bind(x.id, x.kind, JSON.stringify(x)));
		if (x.kind === "delivery" && [
			"En ruta",
			"Entregado",
			"Recogido en local"
		].includes(x.status)) writes.push(db.prepare("UPDATE records SET data=json_set(data,'$.status',?) WHERE id=? AND kind='order' AND json_extract(data,'$.status') NOT IN ('Cancelado','Vencido','Devuelto','Devolución parcial')").bind(x.status === "En ruta" ? "Enviado" : "Entregado", x.orderId));
		const log = audit(actor, old ? "Actualizar " + x.kind : "Crear " + x.kind, x.id);
		writes.push(db.prepare("INSERT INTO records(id,kind,data) VALUES(?,?,?)").bind(log.id, "audit", JSON.stringify(log)));
		await db.batch(writes);
		return Response.json({
			ok: true,
			record: x
		});
	} catch (e) {
		return Response.json({ error: e.message?.includes("NOT NULL") ? "Otro usuario modificó este registro. Actualiza antes de guardar." : e.message || "No se pudo guardar" }, { status: 400 });
	}
}
//#endregion
//#region .generated/app/totals.ts
function orderTotals(subtotal, shipping, config) {
	const rate = Number(config.taxRate || 0), included = config.taxIncluded !== false;
	const tax = Math.round((included ? subtotal - subtotal / (1 + rate / 100) : subtotal * rate / 100) * 100) / 100;
	return {
		subtotal,
		shipping,
		tax,
		taxRate: rate,
		taxIncluded: included,
		total: Math.round((subtotal + shipping + (included ? 0 : tax)) * 100) / 100
	};
}
//#endregion
//#region .generated/app/api/business/route.ts
var route_exports$7 = /* @__PURE__ */ __exportAll({ POST: () => POST$5 });
var num = (x) => {
	const n = Number(x);
	if (!Number.isFinite(n) || n < 0) throw Error("Importe inválido");
	return n;
};
var qty = (x) => {
	const n = num(x);
	if (!Number.isInteger(n) || n < 1) throw Error("Cantidad inválida");
	return n;
};
async function POST$5(req) {
	if (!sameOrigin(req)) return Response.json({ error: "Origen no permitido" }, { status: 403 });
	const actor = await getActor();
	if (!actor) return Response.json({ error: "Acceso administrativo requerido" }, { status: 401 });
	const db = env.DB;
	try {
		const x = await req.json();
		if (!permits(actor, [
			"loss",
			"restock",
			"adjustStock",
			"purchasePayment"
		].includes(x.action) ? "inventory" : x.action === "deliveryPayment" ? "delivery" : "sales")) return Response.json({ error: "No tienes permiso para esta operación" }, { status: 403 });
		if (x.action === "bootstrap" && actor.role !== "owner") return Response.json({ error: "Solo el propietario puede preparar el catálogo" }, { status: 403 });
		if (JSON.stringify(x).length > 2e5) throw Error("Operación demasiado grande");
		await expireReservations(db);
		await snapshot(db, env.BUCKET);
		const now = (/* @__PURE__ */ new Date()).toISOString();
		const all = (await db.prepare("SELECT id,kind,data FROM records").all()).results;
		const rows = all.map((r) => ({
			...JSON.parse(r.data),
			id: r.id,
			kind: r.kind
		}));
		const stored = new Map(all.map((r) => [r.id, r.data]));
		const settings = rows.find((r) => r.kind === "settings");
		if (x.action === "bootstrap") {
			if (settings?.catalogSeedVersion !== 3) {
				const ps = x.products;
				if (!Array.isArray(ps) || ps.length > 300) throw Error("Catálogo inválido");
				const batch = ps.map((p) => db.prepare("INSERT OR IGNORE INTO records(id,kind,data) VALUES(?,?,?)").bind(p.id, "product", JSON.stringify({
					...p,
					kind: "product"
				})));
				const c = {
					...x.config || {},
					...settings,
					id: "config",
					kind: "settings",
					catalogSeedVersion: 3
				};
				batch.push(db.prepare("INSERT INTO records(id,kind,data) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data").bind("config", "settings", JSON.stringify(c)));
				if (batch.length) await db.batch(batch);
			}
			return Response.json({ ok: true });
		}
		const id = String(x.id || crypto.randomUUID());
		if (stored.has(id) && [
			"sale",
			"loss",
			"restock",
			"payment",
			"purchasePayment",
			"return",
			"refund",
			"deliveryPayment",
			"adjustStock"
		].includes(x.action)) return Response.json({
			ok: true,
			id
		});
		const changes = [];
		function create(r) {
			changes.push(db.prepare("INSERT INTO records(id,kind,data) VALUES(?,?,?)").bind(r.id, r.kind, JSON.stringify(r)));
		}
		function update(r) {
			const old = stored.get(r.id);
			if (!old) throw Error("Registro no encontrado");
			const guard = "guard-" + crypto.randomUUID();
			changes.push(db.prepare("UPDATE records SET data=? WHERE id=? AND data=?").bind(JSON.stringify(r), r.id, old));
			changes.push(db.prepare("INSERT INTO records(id,kind,data) VALUES(?,'guard',CASE WHEN changes()=1 THEN '{}' ELSE NULL END)").bind(guard));
			changes.push(db.prepare("DELETE FROM records WHERE id=?").bind(guard));
		}
		const product = (id) => {
			const p = rows.find((r) => r.id === id && r.kind === "product");
			if (!p) throw Error("Pieza no encontrada");
			return p;
		};
		const order = (id) => {
			const o = rows.find((r) => r.id === id && r.kind === "order");
			if (!o) throw Error("Pedido no encontrado");
			return o;
		};
		if (x.action === "sale") {
			if (x.online === true) throw Error("Usa el formulario de solicitud de la tienda");
			if (!x.name?.trim()) throw Error("Indica el cliente");
			if (!Array.isArray(x.items) || !x.items.length || x.items.length > 100) throw Error("Añade piezas");
			const grouped = /* @__PURE__ */ new Map();
			for (const i of x.items) {
				const q = qty(i.qty);
				const before = grouped.get(i.id);
				if (before && before.price !== i.price) throw Error("No mezcles precios distintos para la misma referencia");
				grouped.set(i.id, {
					...i,
					qty: q + (before?.qty || 0)
				});
			}
			const items = [];
			for (const i of grouped.values()) {
				const p = product(i.id), n = qty(i.qty);
				if (x.online === true && p.published === false) throw Error("Esta pieza ya no está publicada: " + p.name);
				if (Number(p.stock) < n) throw Error("Existencias insuficientes: " + p.name);
				const price = x.online === true ? salePrice(withSeasons(p, rows), rows.filter((r) => r.kind === "promotion")).price : num(i.price ?? salePrice(withSeasons(p, rows), rows.filter((r) => r.kind === "promotion")).price);
				const specificationCheck = JSON.stringify([
					p.material || "",
					p.size || "",
					p.dimensions || "",
					p.weight || "",
					p.chain || "",
					p.finish || "",
					p.setting || "",
					p.includes || "",
					p.stone || ""
				]);
				if (x.online === true && i.specificationCheck !== specificationCheck) throw Error("Las características de " + p.name + " cambiaron. Quita la pieza de la bolsa y vuelve a seleccionarla para revisar su ficha.");
				const specifications = Object.fromEntries([
					"sku",
					"material",
					"size",
					"dimensions",
					"weight",
					"chain",
					"finish",
					"setting",
					"includes",
					"stone",
					"materialEn",
					"sizeEn",
					"dimensionsEn",
					"weightEn",
					"chainEn",
					"finishEn",
					"settingEn",
					"includesEn",
					"stoneEn"
				].map((k) => [k, p[k] || ""]));
				items.push({
					id: p.id,
					name: p.name,
					qty: n,
					price,
					specifications,
					cost: p.cost === void 0 || p.cost === null || p.cost === "" ? null : num(p.cost)
				});
				update({
					...p,
					stock: Number(p.stock) - n
				});
			}
			const shipping = num(x.shipping || 0), amounts = orderTotals(items.reduce((s, i) => s + i.price * i.qty, 0), shipping, settings || {}), total = amounts.total, paid = x.online === true ? 0 : num(x.paid || 0);
			if (paid > total) throw Error("El abono supera el total");
			create({
				id,
				kind: "order",
				date: x.date || now,
				name: x.name,
				email: x.email || "",
				phone: x.phone || "",
				channel: x.channel || "Local",
				sourceRef: x.sourceRef || "",
				items,
				...amounts,
				total,
				due: x.reserve ? Math.round(total * Number(settings?.deposit ?? 30)) / 100 : total,
				paid,
				reserve: !!x.reserve,
				status: paid === total ? "Pagado" : paid > 0 ? "Abono confirmado" : "Pendiente de pago",
				delivery: x.delivery || "pickup",
				address: x.address || "",
				note: x.note || "",
				stockBooked: true,
				confirmed: true,
				confirmedAt: x.date || now,
				shipping,
				currency: "DOP",
				exchangeRate: Number(settings?.rate || 60),
				refunded: 0
			});
			if (paid > 0) create({
				id: crypto.randomUUID(),
				kind: "payment",
				orderId: id,
				amount: paid,
				date: now,
				method: x.method || "Transferencia"
			});
		} else if (x.action === "loss") {
			const p = product(x.productId), n = qty(x.qty);
			if (Number(p.stock) < n) throw Error("La pérdida supera las existencias");
			update({
				...p,
				stock: Number(p.stock) - n
			});
			create({
				id,
				kind: "loss",
				date: x.date || now,
				productId: p.id,
				productName: p.name,
				qty: n,
				amount: num(x.amount),
				reason: x.reason || "",
				note: x.note || ""
			});
		} else if (x.action === "restock") {
			const p = product(x.productId), n = qty(x.qty), cost = num(x.unitCost), total = cost * n, paid = num(x.paid || 0);
			if (paid > total) throw Error("El pago supera la compra");
			update({
				...p,
				stock: Number(p.stock) + n,
				cost,
				supplierId: x.supplierId || p.supplierId || ""
			});
			create({
				id,
				kind: "purchase",
				date: x.date || now,
				productId: p.id,
				productName: p.name,
				qty: n,
				unitCost: cost,
				total,
				paid,
				supplierId: x.supplierId || "",
				note: x.note || ""
			});
			if (paid > 0) create({
				id: crypto.randomUUID(),
				kind: "supplierpayment",
				purchaseId: id,
				supplierId: x.supplierId || "",
				date: now,
				amount: paid
			});
		} else if (x.action === "payment") {
			const o = order(x.orderId);
			if (["Cancelado", "Vencido"].includes(o.status) || o.confirmed === false || !o.stockBooked) throw Error("Confirma la solicitud antes de registrar un abono");
			const amount = num(x.amount);
			if (amount <= 0 || amount > Number(o.total) - Number(o.returnedValue || 0) - Number(o.paid || 0) + Number(o.refunded || 0)) throw Error("Abono inválido");
			const paid = Math.round((Number(o.paid || 0) + amount) * 100) / 100;
			update({
				...o,
				paid,
				status: [
					"Preparando",
					"Enviado",
					"Entregado",
					"Devuelto",
					"Devolución parcial"
				].includes(o.status) ? o.status : paid === o.total ? "Pagado" : "Abono confirmado",
				expiresAt: null
			});
			create({
				id,
				kind: "payment",
				orderId: o.id,
				amount,
				date: now,
				method: x.method || "Transferencia",
				reference: x.reference || "",
				note: x.note || ""
			});
		} else if (x.action === "status") {
			const o = order(x.orderId);
			if (["Devuelto", "Devolución parcial"].includes(o.status) && x.status !== o.status) throw Error("Una devolución no se cambia desde el estado de entrega");
			if ((o.confirmed === false || !o.stockBooked) && x.status !== o.status) throw Error("Confirma la solicitud primero");
			if (["Cancelado", "Vencido"].includes(o.status) && x.status !== o.status) throw Error("Un pedido cancelado no puede reabrirse");
			if (![
				"Preparando",
				"Enviado",
				"Entregado",
				o.status
			].includes(x.status)) throw Error("Estado no válido");
			update({
				...o,
				status: x.status
			});
		} else if (x.action === "cancel") {
			const o = order(x.orderId);
			if (o.status === "Cancelado") return Response.json({ ok: true });
			if (Number(o.paid) - Number(o.refunded || 0) > 0) throw Error("Registra el reembolso del dinero recibido antes de cancelar");
			if ((o.returnedItems || []).length || o.status === "Entregado") throw Error("Usa el proceso de devolución para piezas entregadas o devueltas");
			if (o.stockBooked) for (const i of o.items) {
				const p = product(i.id);
				update({
					...p,
					stock: Number(p.stock) + Number(i.qty)
				});
			}
			update({
				...o,
				status: "Cancelado",
				stockBooked: false
			});
		} else if (x.action === "purchasePayment") {
			const p = rows.find((r) => r.id === x.purchaseId && r.kind === "purchase");
			if (!p) throw Error("Compra no encontrada");
			const amount = num(x.amount);
			if (amount <= 0 || amount > p.total - p.paid) throw Error("Pago inválido");
			update({
				...p,
				paid: Number(p.paid) + amount
			});
			create({
				id,
				kind: "supplierpayment",
				purchaseId: p.id,
				supplierId: p.supplierId,
				date: now,
				amount
			});
		} else if (x.action === "confirm") {
			const o = order(x.orderId);
			if (o.stockBooked) return Response.json({
				ok: true,
				id: o.id
			});
			if (o.confirmed !== false || !["Solicitud recibida"].includes(o.status)) throw Error("Esta solicitud no puede confirmarse");
			for (const i of o.items) {
				const p = product(i.id);
				if (specFingerprint(p) !== specFingerprint(i.specifications || {})) throw Error("La ficha de " + p.name + " cambió. Pide al cliente una selección actualizada antes de reservar.");
				if (p.published === false || Number(p.stock) < Number(i.qty)) throw Error("No hay existencias suficientes de " + p.name);
				update({
					...p,
					stock: Number(p.stock) - Number(i.qty)
				});
			}
			const hours = Number(settings?.reservationHours ?? 48);
			if (!Number.isFinite(hours) || hours < 1 || hours > 720) throw Error("Configura entre 1 y 720 horas para las reservas");
			update({
				...o,
				confirmed: true,
				confirmedAt: now,
				stockBooked: true,
				status: "Reserva pendiente de abono",
				expiresAt: new Date(Date.now() + hours * 36e5).toISOString(),
				items: o.items.map((i) => ({
					...i,
					cost: product(i.id).cost == null ? null : num(product(i.id).cost)
				}))
			});
		} else if (x.action === "return") {
			const o = order(x.orderId);
			if (!o.stockBooked || o.confirmed === false || ["Cancelado", "Vencido"].includes(o.status)) throw Error("Este pedido no admite devoluciones");
			if (!x.reason?.trim()) throw Error("Indica el motivo");
			if (!Array.isArray(x.items) || !x.items.length) throw Error("Selecciona las piezas devueltas");
			const selected = /* @__PURE__ */ new Map();
			for (const i of x.items) {
				const n = qty(i.qty);
				if (selected.has(i.id)) throw Error("Pieza duplicada");
				selected.set(i.id, {
					...i,
					qty: n
				});
			}
			const returned = [...o.returnedItems || []], lines = [];
			let value = 0;
			for (const i of selected.values()) {
				const line = o.items.find((p) => p.id === i.id);
				const previous = returned.filter((p) => p.id === i.id).reduce((s, p) => s + p.qty, 0);
				if (!line || i.qty > line.qty - previous) throw Error("Cantidad devuelta no válida");
				const item = {
					id: i.id,
					name: line.name,
					qty: i.qty,
					restock: i.restock === true,
					price: line.price,
					cost: line.cost ?? null
				};
				lines.push(item);
				returned.push(item);
				value += line.price * i.qty * (o.taxIncluded === false ? 1 + Number(o.taxRate || 0) / 100 : 1);
				if (i.restock === true) {
					const p = product(i.id);
					update({
						...p,
						stock: Number(p.stock) + i.qty
					});
				}
			}
			value = Math.round(value * 100) / 100;
			const returnShipping = x.returnShipping === true && !o.shippingReturned ? Number(o.shipping || 0) : 0;
			value = Math.min(Math.round((value + returnShipping) * 100) / 100, Number(o.total) - Number(o.returnedValue || 0));
			const allReturned = o.items.every((i) => returned.filter((r) => r.id === i.id).reduce((s, r) => s + r.qty, 0) === i.qty);
			update({
				...o,
				returnedItems: returned,
				shippingReturned: !!o.shippingReturned || returnShipping > 0,
				returnedValue: Math.round((Number(o.returnedValue || 0) + value) * 100) / 100,
				status: allReturned ? "Devuelto" : "Devolución parcial",
				expiresAt: null
			});
			create({
				id,
				kind: "return",
				orderId: o.id,
				date: now,
				items: lines,
				shipping: returnShipping,
				amount: Math.round(value * 100) / 100,
				reason: x.reason,
				note: x.note || ""
			});
		} else if (x.action === "refund") {
			const o = order(x.orderId), amount = num(x.amount), refunded = Number(o.refunded || 0);
			if (!x.reason?.trim() || !x.reference?.trim()) throw Error("Indica motivo y referencia del dinero devuelto");
			if (amount <= 0 || amount > Number(o.paid || 0) - refunded) throw Error("El reembolso supera el dinero recibido pendiente de devolver");
			if (amount > Number(o.returnedValue || 0) + (x.cancelOrder === true && !o.returnedItems?.length && o.status !== "Entregado" ? Number(o.total) : 0) - refunded) throw Error("Registra primero la devolución o indica cancelación del pedido completo");
			if (x.cancelOrder === true && o.status === "Entregado") throw Error("Registra la devolución antes de cancelar una entrega");
			let next = {
				...o,
				refunded: Math.round((refunded + amount) * 100) / 100
			};
			if (x.cancelOrder === true) {
				if (next.refunded !== Number(o.paid)) throw Error("Para cancelar debes devolver todo el dinero recibido");
				if (o.returnedItems?.length) throw Error("Usa la devolución registrada para este pedido");
				if (o.stockBooked) for (const i of o.items) {
					const p = product(i.id);
					update({
						...p,
						stock: Number(p.stock) + Number(i.qty)
					});
				}
				next = {
					...next,
					status: "Cancelado",
					stockBooked: false,
					expiresAt: null
				};
			}
			update(next);
			create({
				id,
				kind: "refund",
				orderId: o.id,
				amount,
				date: now,
				reason: x.reason,
				method: x.method || "Transferencia",
				reference: x.reference,
				note: x.note || ""
			});
		} else if (x.action === "deliveryPayment") {
			const d = rows.find((r) => r.id === x.deliveryId && r.kind === "delivery");
			if (!d) throw Error("Entrega no encontrada");
			const amount = num(x.amount);
			if (amount <= 0 || amount > Number(d.cost || 0) - Number(d.paid || 0)) throw Error("Pago de delivery no válido");
			update({
				...d,
				paid: Number(d.paid || 0) + amount
			});
			create({
				id,
				kind: "expense",
				date: now,
				name: "Pago de delivery " + d.orderId,
				category: "Delivery",
				amount,
				deliveryId: d.id,
				reference: x.reference || "",
				locked: true
			});
		} else if (x.action === "adjustStock") {
			if (!permits(actor, "inventory")) throw Error("Permiso de inventario requerido");
			const p = product(x.productId), stock = Number(x.stock);
			if (!Number.isInteger(stock) || stock < 0 || !x.reason?.trim()) throw Error("Indica stock contado y motivo");
			update({
				...p,
				stock
			});
			create({
				id,
				kind: "stockmovement",
				date: now,
				productId: p.id,
				before: p.stock,
				after: stock,
				delta: stock - p.stock,
				reason: x.reason
			});
		} else if (x.action === "voidExpense") {
			if (actor.role !== "owner") throw Error("Solo el propietario puede anular gastos");
			const e = rows.find((r) => r.id === x.expenseId && r.kind === "expense");
			if (!e || e.voided || e.locked || !x.reason?.trim()) throw Error("Gasto no anulable o motivo faltante");
			update({
				...e,
				voided: true,
				voidReason: x.reason,
				voidedAt: now
			});
		} else throw Error("Acción no válida");
		create(audit(actor, x.action, x.orderId || x.productId || id, { note: String(x.reason || x.note || "").slice(0, 500) }));
		if (changes.length) await db.batch(changes);
		return Response.json({
			ok: true,
			id
		});
	} catch (e) {
		return Response.json({ error: e.message?.includes("NOT NULL") ? "Otro cambio modificó las existencias. Actualiza e inténtalo de nuevo." : e.message || "No se pudo guardar" }, { status: 400 });
	}
}
//#endregion
//#region .generated/app/api/request/route.ts
var route_exports$6 = /* @__PURE__ */ __exportAll({ POST: () => POST$4 });
async function POST$4(req) {
	try {
		if (req.headers.get("origin") && req.headers.get("origin") !== new URL(req.url).origin) return Response.json({ error: "Origen no permitido" }, { status: 403 });
		const x = await req.json();
		if (JSON.stringify(x).length > 25e3) throw Error("Solicitud demasiado grande");
		if (x.website) throw Error("No se pudo enviar");
		if (!x.name?.trim() || !/^\S+@\S+\.\S+$/.test(x.email || "") || String(x.phone || "").replace(/\D/g, "").length < 7) throw Error("Revisa nombre, correo y teléfono");
		if (!["pickup", "delivery"].includes(x.delivery) || x.delivery === "delivery" && !x.address?.trim()) throw Error("Completa la dirección de entrega");
		const db = env.DB;
		const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode((req.headers.get("cf-connecting-ip") || "unknown") + "|" + (/* @__PURE__ */ new Date()).toISOString().slice(0, 13)));
		const rid = "rate-" + Array.from(new Uint8Array(digest)).map((n) => n.toString(16).padStart(2, "0")).join("");
		await db.prepare("INSERT INTO records(id,kind,data) VALUES(?,'ratelimit','{\"count\":1}') ON CONFLICT(id) DO UPDATE SET data=json_set(data,'$.count',json_extract(data,'$.count')+1)").bind(rid).run();
		const rate = await db.prepare("SELECT data FROM records WHERE id=?").bind(rid).first();
		if (JSON.parse(rate.data).count > 10) return Response.json({ error: "Has enviado varias solicitudes. Inténtalo más tarde." }, { status: 429 });
		const rows = (await db.prepare("SELECT data FROM records WHERE kind IN ('product','settings','promotion','collection')").all()).results.map((r) => JSON.parse(r.data));
		const c = rows.find((r) => r.kind === "settings") || {};
		if (x.type === "inquiry") {
			if (!x.message?.trim()) throw Error("Escribe tu consulta");
			const p = rows.find((p) => p.id === x.productId && p.kind === "product" && p.published !== false);
			if (!p) throw Error("Pieza no disponible");
			const inquiry = {
				id: crypto.randomUUID(),
				kind: "inquiry",
				product: p.name,
				productId: p.id,
				name: x.name,
				email: x.email,
				phone: x.phone,
				message: String(x.message).slice(0, 5e3),
				date: (/* @__PURE__ */ new Date()).toISOString(),
				status: "Pendiente"
			};
			const n = {
				id: crypto.randomUUID(),
				kind: "notification",
				date: inquiry.date,
				name: "Nueva consulta sobre " + p.name,
				inquiryId: inquiry.id,
				read: false
			};
			await db.batch([db.prepare("INSERT INTO records(id,kind,data) VALUES(?,?,?)").bind(inquiry.id, "inquiry", JSON.stringify(inquiry)), db.prepare("INSERT INTO records(id,kind,data) VALUES(?,?,?)").bind(n.id, "notification", JSON.stringify(n))]);
			return Response.json({ ok: true });
		}
		if (!x.specificationsReviewed || !Array.isArray(x.items) || !x.items.length || x.items.length > 50) throw Error("Revisa las características de tus piezas");
		const grouped = /* @__PURE__ */ new Map();
		for (const i of x.items) {
			if (!Number.isInteger(i.qty) || i.qty < 1 || i.qty > 100) throw Error("Cantidad no válida");
			const prev = grouped.get(i.id);
			grouped.set(i.id, {
				...i,
				qty: i.qty + (prev?.qty || 0)
			});
		}
		const items = [];
		for (const i of grouped.values()) {
			const p = rows.find((p) => p.id === i.id && p.kind === "product" && p.published !== false);
			if (!p || p.stock < i.qty) throw Error("Pieza no disponible. Revisa tu bolsa.");
			if (specFingerprint(p) !== i.specificationCheck) throw Error("Las características cambiaron. Vuelve a seleccionar " + p.name);
			items.push({
				id: p.id,
				name: p.name,
				qty: i.qty,
				price: salePrice(withSeasons(p, rows), rows.filter((r) => r.kind === "promotion")).price,
				specifications: specifications(p)
			});
		}
		const token = typeof x.requestToken === "string" && /^[a-f0-9-]{72}$/.test(x.requestToken) ? x.requestToken : crypto.randomUUID() + crypto.randomUUID(), hash = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token)))).map((n) => n.toString(16).padStart(2, "0")).join("");
		const amounts = orderTotals(items.reduce((s, p) => s + p.qty * p.price, 0), x.delivery === "delivery" ? Number(c.shipping || 0) : 0, c), total = amounts.total;
		const id = "LA-" + hash.slice(0, 16).toUpperCase();
		const existing = await db.prepare("SELECT data FROM records WHERE id=? AND kind='order'").bind(id).first();
		if (existing) {
			const old = JSON.parse(existing.data);
			if (old.trackingHash !== hash) throw Error("Solicitud duplicada");
			return Response.json({
				ok: true,
				order: customerOrder(old),
				token
			});
		}
		const order = {
			id,
			kind: "order",
			date: (/* @__PURE__ */ new Date()).toISOString(),
			name: String(x.name).slice(0, 200),
			email: x.email,
			phone: x.phone,
			address: x.delivery === "delivery" ? x.address : c.address || "",
			...amounts,
			delivery: x.delivery,
			reserve: !!x.reserve,
			items,
			total,
			shipping: x.delivery === "delivery" ? Number(c.shipping || 0) : 0,
			due: x.reserve ? Math.round(total * Number(c.deposit ?? 30)) / 100 : total,
			paid: 0,
			refunded: 0,
			status: "Solicitud recibida",
			confirmed: false,
			stockBooked: false,
			channel: "Web",
			note: String(x.note || "").slice(0, 3e3),
			currency: "DOP",
			exchangeRate: Number(c.rate || 60),
			trackingHash: hash
		};
		const notification = {
			id: crypto.randomUUID(),
			kind: "notification",
			date: order.date,
			name: "Nueva solicitud " + id,
			orderId: id,
			read: false
		};
		const log = audit(null, "Solicitud recibida", id);
		await db.batch([
			db.prepare("INSERT INTO records(id,kind,data) VALUES(?,?,?)").bind(id, "order", JSON.stringify(order)),
			db.prepare("INSERT INTO records(id,kind,data) VALUES(?,?,?)").bind(notification.id, "notification", JSON.stringify(notification)),
			db.prepare("INSERT INTO records(id,kind,data) VALUES(?,?,?)").bind(log.id, "audit", JSON.stringify(log))
		]);
		return Response.json({
			ok: true,
			order: customerOrder(order),
			token
		});
	} catch (e) {
		return Response.json({ error: e.message || "No se pudo enviar" }, { status: 400 });
	}
}
//#endregion
//#region .generated/app/api/order-status/route.ts
var route_exports$5 = /* @__PURE__ */ __exportAll({ POST: () => POST$3 });
async function POST$3(req) {
	const x = await req.json();
	if (typeof x.token !== "string" || x.token.length > 200) return Response.json({ error: "Acceso no válido" }, { status: 403 });
	const hash = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(x.token)))).map((n) => n.toString(16).padStart(2, "0")).join("");
	const r = await env.DB.prepare("SELECT data FROM records WHERE id=? AND kind='order'").bind(x.id).first();
	const o = r ? JSON.parse(r.data) : null;
	if (!o || o.trackingHash !== hash) return Response.json({ error: "Solicitud no encontrada" }, { status: 404 });
	return Response.json({
		id: o.id,
		status: o.status,
		total: o.total,
		paid: o.paid,
		refunded: o.refunded || 0,
		reserve: o.reserve,
		expiresAt: o.expiresAt,
		delivery: o.delivery,
		confirmed: o.confirmed,
		items: o.items.map((i) => ({
			name: i.name,
			qty: i.qty,
			specifications: i.specifications
		}))
	}, { headers: { "Cache-Control": "no-store" } });
}
//#endregion
//#region .generated/app/api/backup/route.ts
var route_exports$4 = /* @__PURE__ */ __exportAll({
	GET: () => GET$2,
	POST: () => POST$2
});
async function POST$2(req) {
	if (!sameOrigin(req)) return Response.json({ error: "Origen no permitido" }, { status: 403 });
	const actor = await getActor();
	if (actor?.role !== "owner") return Response.json({ error: "Solo el propietario puede gestionar respaldos" }, { status: 403 });
	try {
		const x = await req.json(), db = env.DB;
		if (x.action === "create") {
			const b = await snapshot(db, env.BUCKET, String(x.label || "Respaldo manual").slice(0, 200), true);
			return Response.json({
				ok: true,
				backup: b
			});
		}
		if (x.action === "restore") {
			if (x.confirm !== "RESTAURAR") throw Error("Escribe RESTAURAR para confirmar");
			const r = await db.prepare("SELECT data FROM records WHERE id=? AND kind='backup'").bind(x.id).first();
			if (!r) throw Error("Respaldo no encontrado");
			const meta = JSON.parse(r.data), file = await env.BUCKET.get(meta.key);
			if (!file) throw Error("Archivo de respaldo no disponible");
			const b = JSON.parse(await file.text());
			if (b.format !== "larimar-backup-v1" || !Array.isArray(b.rows) || b.rows.length > 5e3) throw Error("Formato de respaldo no válido");
			for (const r of b.rows) {
				const v = JSON.parse(r.data);
				if (v.id !== r.id || v.kind !== r.kind) throw Error("Respaldo inconsistente");
			}
			await snapshot(db, env.BUCKET, "Antes de restaurar " + meta.id, true);
			const writes = [db.prepare("DELETE FROM records WHERE kind NOT IN ('backup','audit','staff')"), ...b.rows.filter((r) => ![
				"backup",
				"audit",
				"staff"
			].includes(r.kind)).map((r) => db.prepare("INSERT INTO records(id,kind,data) VALUES(?,?,?)").bind(r.id, r.kind, r.data))];
			const log = audit(actor, "Restaurar respaldo", meta.id, { label: meta.label });
			writes.push(db.prepare("INSERT INTO records(id,kind,data) VALUES(?,?,?)").bind(log.id, "audit", JSON.stringify(log)));
			await db.batch(writes);
			return Response.json({ ok: true });
		}
		throw Error("Acción no válida");
	} catch (e) {
		return Response.json({ error: e.message || "No se pudo gestionar el respaldo" }, { status: 400 });
	}
}
async function GET$2(req) {
	if ((await getActor())?.role !== "owner") return Response.json({ error: "Acceso requerido" }, { status: 403 });
	const id = new URL(req.url).searchParams.get("id");
	const r = await env.DB.prepare("SELECT data FROM records WHERE id=? AND kind='backup'").bind(id).first();
	if (!r) return new Response("No encontrado", { status: 404 });
	const b = await env.BUCKET.get(JSON.parse(r.data).key);
	if (!b) return new Response("No encontrado", { status: 404 });
	return new Response(b.body, { headers: {
		"Content-Type": "application/json",
		"Content-Disposition": "attachment; filename=\"larimar-respaldo.json\"",
		"Cache-Control": "no-store"
	} });
}
//#endregion
//#region .generated/app/api/receipt/[id]/route.ts
var route_exports$3 = /* @__PURE__ */ __exportAll({ GET: () => GET$1 });
var escape$1 = (x) => String(x ?? "").replace(/[&<>"']/g, (c) => ({
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;"
})[c]);
async function GET$1(req, { params }) {
	if (!permits(await getActor(), "sales")) return new Response("Acceso requerido", { status: 403 });
	const { id } = await params;
	const rows = (await env.DB.prepare("SELECT data FROM records WHERE kind IN ('order','payment','refund','return','settings')").all()).results.map((r) => JSON.parse(r.data));
	const document = rows.find((r) => r.id === id);
	if (!document || document.kind === "settings") return new Response("No encontrado", { status: 404 });
	const o = document.kind === "order" ? document : rows.find((r) => r.id === document.orderId && r.kind === "order");
	if (!o) return new Response("Pedido no encontrado", { status: 404 });
	const config = rows.find((r) => r.kind === "settings") || {}, money = (n) => new Intl.NumberFormat("es-DO", {
		style: "currency",
		currency: "DOP"
	}).format(Number(n || 0));
	const lines = (document.kind === "return" ? document.items : o.items).map((i) => `<tr><td>${escape$1(i.name)}<small>${escape$1(Object.values(i.specifications || {}).filter(Boolean).slice(0, 10).join(" · "))}</small></td><td>${escape$1(i.qty)}</td><td>${money(i.price)}</td><td>${money(i.qty * i.price)}</td></tr>`).join("");
	const title = escape$1(document.kind === "payment" ? "Recibo de abono" : document.kind === "refund" ? "Constancia de reembolso" : document.kind === "return" ? "Constancia de devolución" : o.confirmed === false ? "Resumen de solicitud" : "Comprobante de venta");
	return new Response(`<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title} · ${escape$1(id)}</title><style>body{font:14px Arial;color:#173c40;max-width:820px;margin:40px auto;padding:24px}header{border-bottom:2px solid;padding-bottom:24px;display:flex;justify-content:space-between;gap:20px}h1{font-size:26px}small{display:block;font-size:11px;color:#536b6d;line-height:1.7}table{width:100%;border-collapse:collapse;margin:30px 0}td,th{text-align:left;border-bottom:1px solid #cbd6d5;padding:12px 7px}article{background:#edf4f2;padding:20px}p{line-height:1.7}button{padding:12px 20px;background:#173c40;color:white;border:0;cursor:pointer}@media print{button{display:none}body{margin:0;padding:10px}}</style><header><div><h1>${escape$1(config.brand || "Larimar Atelier")}</h1><p>${escape$1(config.address || "")}<small>${escape$1(config.phone || "")} ${escape$1(config.email || "")}</small></p></div><div><b>${title}</b><p>${escape$1(id)}<small>Pedido: ${escape$1(o.id)}</small><small>${escape$1(new Date(document.date).toLocaleString("es-DO", { timeZone: "America/Santo_Domingo" }))}</small></p></div></header><p>Cliente: <b>${escape$1(o.name)}</b><br>${escape$1(o.email)} · ${escape$1(o.phone)}</p><table><thead><tr><th>Pieza</th><th>Cantidad</th><th>Unitario</th><th>Importe</th></tr></thead><tbody>${lines}</tbody></table><article>Total del pedido: <b>${money(o.total)}</b><br>Impuesto calculado (${escape$1(o.taxRate || 0)}%${o.taxIncluded !== false ? " incluido" : ""}): ${money(o.tax)}<br>Abonos recibidos: ${money(o.paid)}<br>Devoluciones de mercancía: ${money(o.returnedValue)}<br>Dinero reembolsado: ${money(o.refunded)}<br>Saldo comercial pendiente: ${money(Math.max(0, o.total - Number(o.returnedValue || 0) - o.paid + Number(o.refunded || 0)))}${document.kind !== "order" ? `<p>Importe de este movimiento: <b>${money(document.amount)}</b><br>Método: ${escape$1(document.method || "No aplica")}<br>Referencia: ${escape$1(document.reference || "—")}<br>Motivo: ${escape$1(document.reason || "—")}</p>` : ""}</article><p><b>DOCUMENTO NO FISCAL · NO VÁLIDO PARA CRÉDITO FISCAL</b><small>Los abonos y reembolsos corresponden a registros manuales. Este documento no realiza ni verifica transferencias bancarias.</small></p><button onclick="window.print()">Imprimir / guardar PDF</button></html>`, { headers: {
		"Content-Type": "text/html; charset=utf-8",
		"Cache-Control": "no-store",
		"Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'self'"
	} });
}
//#endregion
//#region .generated/app/api/media/[key]/route.ts
var route_exports$2 = /* @__PURE__ */ __exportAll({ GET: () => GET });
async function GET(req, { params }) {
	const { key } = await params;
	if (!/^[a-f0-9-]{36}$/.test(key)) return new Response("No encontrado", { status: 404 });
	if (!await getActor()) {
		if (!(await env.DB.prepare("SELECT data FROM records WHERE kind IN ('product','settings','collection')").all()).results.some((r) => {
			const x = JSON.parse(r.data);
			return (x.kind === "settings" || x.kind === "product" && x.published !== false || x.kind === "collection" && x.active) && JSON.stringify(publicRecord(x)).includes("/larimar/api/media/" + key);
		})) return new Response("No encontrado", { status: 404 });
	}
	const file = await env.BUCKET.get(key);
	if (!file) return new Response("No encontrado", { status: 404 });
	return new Response(file.body, { headers: {
		"Content-Type": file.httpMetadata?.contentType || "application/octet-stream",
		"Cache-Control": "private, max-age=3600",
		"X-Content-Type-Options": "nosniff"
	} });
}
//#endregion
//#region .generated/app/api/upload/route.ts
var route_exports$1 = /* @__PURE__ */ __exportAll({ POST: () => POST$1 });
async function POST$1(req) {
	if (!sameOrigin(req)) return Response.json({ error: "Origen no permitido" }, { status: 403 });
	if (!permits(await getActor(), "product")) return Response.json({ error: "Acceso requerido" }, { status: 401 });
	try {
		const f = (await req.formData()).get("file");
		if (!(f instanceof File) || f.size > 8 * 1024 * 1024 || f.size === 0) throw Error("Selecciona una imagen de hasta 8 MB");
		const b = new Uint8Array(await f.arrayBuffer());
		const type = b[0] === 255 && b[1] === 216 ? "image/jpeg" : b[0] === 137 && b[1] === 80 ? "image/png" : String.fromCharCode(...b.slice(0, 4)) === "RIFF" && String.fromCharCode(...b.slice(8, 12)) === "WEBP" ? "image/webp" : String.fromCharCode(...b.slice(0, 3)) === "GIF" ? "image/gif" : null;
		if (!type) throw Error("Usa JPG, PNG, WEBP o GIF");
		const key = crypto.randomUUID();
		await env.BUCKET.put(key, b, { httpMetadata: { contentType: type } });
		return Response.json({ url: "/larimar/api/media/" + key });
	} catch (e) {
		return Response.json({ error: e.message || "No se pudo subir la imagen" }, { status: 400 });
	}
}
//#endregion
//#region .generated/app/translation-service.ts
var known = {
	"Larimar": "Larimar",
	"Plata 925": "Sterling silver 925",
	"Oro": "Gold",
	"Plata": "Silver",
	"No aplica": "Not applicable",
	"Reverso cerrado": "Closed back",
	"Reverso cerrado en plata": "Closed silver back",
	"Cadena no incluida": "Chain not included",
	"Anillo · una pieza": "Ring · one piece",
	"Colgante · cadena por separado": "Pendant · chain sold separately",
	"Pulsera · una pieza": "Bracelet · one piece"
};
function splitTranslation(text, maxBytes = 450) {
	const chunks = [];
	let current = "";
	const encoder = new TextEncoder();
	for (const token of text.split(/(\s+)/u)) for (const char of token) {
		if (encoder.encode(current + char).length > maxBytes) {
			let cut = current.lastIndexOf(" ");
			if (cut > current.length / 2) {
				chunks.push(current.slice(0, cut));
				current = current.slice(cut + 1);
			} else {
				chunks.push(current);
				current = "";
			}
		}
		current += char;
	}
	if (current.trim()) chunks.push(current);
	return chunks.filter((chunk) => chunk.trim());
}
function decodeTranslation(text) {
	return text.replace(/&#x([0-9a-f]+);/gi, (_, h) => {
		const n = parseInt(h, 16);
		return n <= 1114111 ? String.fromCodePoint(n) : "";
	}).replace(/&#(\d+);/g, (_, d) => {
		const n = Number(d);
		return n <= 1114111 ? String.fromCodePoint(n) : "";
	}).replace(/&quot;/g, "\"").replace(/&apos;|&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
}
async function translateText(text, db, fetcher = fetch) {
	const source = text.trim();
	if (!source) return "";
	if (known[source]) return known[source];
	if (/^[\d\s.,×x≈°%½¼¾/()\-–+]+(?:\s*(?:g|gr|kg|mm|cm|m|US|EU|in|oz|k|K))*$/u.test(source)) return source;
	const id = "translation:" + Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode("es|en|v1|" + source)))).map((b) => b.toString(16).padStart(2, "0")).join("");
	const cached = await db.prepare("SELECT data FROM records WHERE id=? AND kind='translation'").bind(id).first();
	if (cached) {
		const c = JSON.parse(cached.data);
		if (c.source === source && c.text) return c.text;
	}
	if (source.length > 1e4) throw Error("El texto es demasiado largo para traducirlo de una vez");
	const translated = [];
	for (const chunk of splitTranslation(source)) {
		const url = new URL("https://api.mymemory.translated.net/get");
		url.searchParams.set("q", chunk.trim());
		url.searchParams.set("langpair", "es|en");
		url.searchParams.set("mt", "1");
		const response = await fetcher(url, {
			signal: AbortSignal.timeout(12e3),
			headers: { Accept: "application/json" }
		});
		if (!response.ok) throw Error("El servicio de traducción no está disponible");
		const data = await response.json();
		const value = data.responseData?.translatedText;
		if (Number(data.responseStatus) !== 200 || data.quotaFinished || typeof value !== "string" || !value.trim() || /MYMEMORY WARNING|QUERY LENGTH LIMIT|PLEASE SELECT TWO DISTINCT|USED ALL AVAILABLE FREE TRANSLATIONS/i.test(value)) throw Error("El servicio de traducción está temporalmente limitado");
		translated.push(decodeTranslation(value));
	}
	const result = translated.join(" ");
	await db.prepare("INSERT INTO records(id,kind,data) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data").bind(id, "translation", JSON.stringify({
		id,
		kind: "translation",
		source,
		text: result,
		target: "en",
		provider: "MyMemory",
		date: (/* @__PURE__ */ new Date()).toISOString()
	})).run();
	return result;
}
//#endregion
//#region .generated/app/api/translate/route.ts
var route_exports = /* @__PURE__ */ __exportAll({ POST: () => POST });
async function POST(req) {
	if (!sameOrigin(req)) return Response.json({ error: "Origen no permitido" }, { status: 403 });
	const actor = await getActor();
	try {
		const x = await req.json();
		if (typeof x.id !== "string") throw Error("Registro inválido");
		const r = await env.DB.prepare("SELECT data FROM records WHERE id=?").bind(x.id).first();
		if (!r) throw Error("Registro no encontrado");
		const record = JSON.parse(r.data);
		if (!actor && (record.kind === "product" && record.published === false || ["collection", "promotion"].includes(record.kind) && !record.active)) return Response.json({ error: "No encontrado" }, { status: 404 });
		if (![
			"product",
			"settings",
			"promotion",
			"collection"
		].includes(record.kind)) return Response.json({ error: "Solo se traduce el contenido de la tienda" }, { status: 400 });
		const result = structuredClone(record);
		let completed = 0, failed = false;
		for (const pair of missingTranslations(record).slice(0, 12)) try {
			const translation = await translateText(pair.text, env.DB);
			put(result, pair.target, translation);
			result._autoTranslationSources = {
				...result._autoTranslationSources || {},
				[pair.target]: pair.text
			};
			completed++;
		} catch {
			failed = true;
			break;
		}
		if (completed) await env.DB.prepare("UPDATE records SET data=? WHERE id=? AND data=?").bind(JSON.stringify(result), record.id, r.data).run();
		const latest = await env.DB.prepare("SELECT data FROM records WHERE id=?").bind(record.id).first();
		const saved = latest ? JSON.parse(latest.data) : result;
		return Response.json({
			record: publicRecord(saved),
			completed,
			pending: missingTranslations(saved).length,
			status: failed ? "unavailable" : missingTranslations(saved).length ? "partial" : "ready"
		});
	} catch (e) {
		return Response.json({ error: e.message || "No se pudo traducir" }, { status: 400 });
	}
}
//#endregion
//#region server/index.mjs
if (process.env.NO_SEED !== "1" && Number(sql.prepare("SELECT count(*) AS n FROM records WHERE kind IN ('product','settings')").get().n) === 0 && fs.existsSync("seed.json")) {
	const seed = JSON.parse(fs.readFileSync("seed.json", "utf8"));
	sql.exec("BEGIN");
	try {
		for (const r of seed) sql.prepare("INSERT OR IGNORE INTO records(id,kind,data) VALUES(?,?,?)").run(r.id, r.kind, JSON.stringify(r));
		sql.exec("COMMIT");
	} catch (e) {
		sql.exec("ROLLBACK");
		throw e;
	}
}
var base = String(process.env.BASE_PATH || "/larimar").replace(/\/$/, ""), port = Number(process.env.PORT || 4401), staticDir = path.resolve("dist"), attempts = /* @__PURE__ */ new Map();
var escape = (s) => String(s).replace(/[&<>"']/g, (c) => ({
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;"
})[c]);
var loginPage = (message = "") => `<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Larimar Atelier · Acceso</title><style>body{margin:0;background:#f8f7f3;color:#173c40;font:14px Arial;min-height:100vh;display:grid;place-items:center}main{width:min(390px,80vw);padding:38px;background:white;border:1px solid #c7e1df}small{letter-spacing:3px}h1{font:42px Georgia;font-weight:normal}label{display:block;margin:24px 0 9px}input{box-sizing:border-box;width:100%;padding:15px;border:1px solid #c7e1df;font:inherit}button{width:100%;padding:17px;margin:25px 0;background:#173c40;color:white;border:0;cursor:pointer}a{color:inherit}p{line-height:1.7}</style><main><small>LARIMAR ATELIER</small><h1>Tu negocio,<br>en tus manos.</h1><p>Acceso privado para el equipo de la joyería.</p>${message ? `<p role="alert">${escape(message)}</p>` : ""}<form method="post" action="${base}/login"><label>Correo electrónico</label><input name="email" type="email" required autocomplete="username"><label>Contraseña</label><input name="password" type="password" required autocomplete="current-password"><button>Entrar al CRM</button></form><a href="${base}/">Volver a la tienda</a></main></html>`;
async function send(res, response) {
	res.statusCode = response.status;
	for (const [k, v] of response.headers) res.setHeader(k, v);
	res.setHeader("X-Content-Type-Options", "nosniff");
	res.setHeader("Referrer-Policy", "same-origin");
	if (response.body) Readable.fromWeb(response.body).pipe(res);
	else res.end();
}
function redirect(res, url, cookie) {
	res.writeHead(303, {
		Location: url,
		...cookie ? { "Set-Cookie": cookie } : {}
	});
	res.end();
}
var routeMap = {
	"/api/shop": route_exports$10,
	"/api/access": route_exports$9,
	"/api/store": route_exports$8,
	"/api/business": route_exports$7,
	"/api/request": route_exports$6,
	"/api/order-status": route_exports$5,
	"/api/backup": route_exports$4,
	"/api/upload": route_exports$1,
	"/api/translate": route_exports
};
async function handle(req, res) {
	const secure = req.headers["x-forwarded-proto"] === "https", url = new URL(req.url, `${secure ? "https" : "http"}://${req.headers.host}`);
	if (url.pathname === base) return redirect(res, base + "/");
	if (base && !url.pathname.startsWith(base + "/")) return send(res, new Response("No encontrado", { status: 404 }));
	const local = url.pathname.slice(base.length) || "/";
	const user = identity(req);
	return context.run(user, async () => {
		if (local === "/health") return send(res, Response.json({ ok: true }));
		if (local === "/login" && req.method === "GET") return send(res, new Response(loginPage(), { headers: {
			"Content-Type": "text/html;charset=utf-8",
			"Cache-Control": "no-store"
		} }));
		if (local === "/logout") {
			if (req.method !== "POST") return send(res, new Response(`<form method="post"><button>Cerrar sesión del CRM</button></form>`, { headers: { "Content-Type": "text/html" } }));
			if (req.headers.origin && req.headers.origin !== url.origin) return send(res, new Response("Origen no permitido", { status: 403 }));
			const token = String(req.headers.cookie || "").match(/(?:^|;\s*)larimar_session=([^;]+)/)?.[1];
			if (token) sql.prepare("DELETE FROM sessions WHERE hash=?").run(digest(token));
			return redirect(res, base + "/", `larimar_session=; Path=${base || "/"}; HttpOnly; SameSite=Lax; Max-Age=0${secure ? "; Secure" : ""}`);
		}
		let bytes = Buffer.alloc(0);
		if (!["GET", "HEAD"].includes(req.method)) for await (const chunk of req) {
			if (bytes.length + chunk.length > 9 * 1024 * 1024) return send(res, new Response("Archivo demasiado grande", { status: 413 }));
			bytes = Buffer.concat([bytes, chunk]);
		}
		if (local === "/login" && req.method === "POST") {
			if (!secure && process.env.ALLOW_HTTP !== "1") return send(res, new Response("Usa HTTPS para iniciar sesión", { status: 403 }));
			if (req.headers.origin && req.headers.origin !== url.origin) return send(res, new Response("Origen no permitido", { status: 403 }));
			const ip = req.headers["x-real-ip"] || req.socket.remoteAddress;
			const previous = attempts.get(ip);
			const a = previous && previous.until > Date.now() ? previous : {
				count: 0,
				until: Date.now() + 15 * 6e4
			};
			a.count++;
			attempts.set(ip, a);
			if (attempts.size > 1e4) {
				for (const [k, v] of attempts) if (v.until < Date.now()) attempts.delete(k);
			}
			if (a.count > 10) return send(res, new Response(loginPage("Demasiados intentos. Espera 15 minutos."), {
				status: 429,
				headers: { "Content-Type": "text/html;charset=utf-8" }
			}));
			const body = new URLSearchParams(bytes.toString()), email = String(body.get("email") || "").trim().toLowerCase(), password = String(body.get("password") || "");
			if (password.length > 200 || !verify(email, password)) return send(res, new Response(loginPage("Correo o contraseña incorrectos."), {
				status: 401,
				headers: { "Content-Type": "text/html;charset=utf-8" }
			}));
			if (email !== ownerEmail) {
				if (!sql.prepare("SELECT data FROM records WHERE kind='staff'").all().map((r) => JSON.parse(r.data)).some((s) => s.email === email && s.active)) return send(res, new Response(loginPage("Acceso no autorizado."), {
					status: 403,
					headers: { "Content-Type": "text/html;charset=utf-8" }
				}));
			}
			attempts.delete(ip);
			const token = createSession(email);
			return redirect(res, base + "/#crm", `larimar_session=${token}; Path=${base || "/"}; HttpOnly; SameSite=Lax; Max-Age=43200${secure ? "; Secure" : ""}`);
		}
		let routes = routeMap[local], params = {};
		if (local.startsWith("/api/media/")) {
			routes = route_exports$2;
			params = { key: local.slice(11) };
		}
		if (local.startsWith("/api/receipt/")) {
			routes = route_exports$3;
			params = { id: decodeURIComponent(local.slice(13)) };
		}
		if (routes) {
			const handler = routes[req.method];
			if (!handler) return send(res, new Response("Método no permitido", { status: 405 }));
			const headers = new Headers();
			for (const [k, v] of Object.entries(req.headers)) if (v !== void 0 && !["host", "content-length"].includes(k)) headers.set(k, Array.isArray(v) ? v.join(",") : v);
			headers.set("cf-connecting-ip", String(req.headers["x-real-ip"] || req.socket.remoteAddress));
			let localPassword = null, email = null;
			if (local === "/api/store" && req.method === "POST") {
				let x;
				try {
					x = JSON.parse(bytes.toString());
				} catch {
					return send(res, Response.json({ error: "JSON no válido" }, { status: 400 }));
				}
				if (x.kind === "staff") {
					if ((await getActor())?.role !== "owner") return send(res, Response.json({ error: "Solo la propietaria puede gestionar accesos" }, { status: 403 }));
					email = String(x.email || "").trim().toLowerCase();
					localPassword = x.password;
					delete x.password;
					if (!sql.prepare("SELECT email FROM users WHERE email=?").get(email) && !localPassword) return send(res, Response.json({ error: "Define una contraseña inicial de al menos 12 caracteres" }, { status: 400 }));
					if (localPassword && (typeof localPassword !== "string" || localPassword.length < 12 || localPassword.length > 200)) return send(res, Response.json({ error: "Contraseña de 12 a 200 caracteres requerida" }, { status: 400 }));
					bytes = Buffer.from(JSON.stringify(x));
				}
			}
			const response = await handler(new Request(url, {
				method: req.method,
				headers,
				...!["GET", "HEAD"].includes(req.method) ? { body: bytes } : {}
			}), { params: Promise.resolve(params) });
			if (response.ok && localPassword) setPassword(email, localPassword);
			return send(res, response);
		}
		if (local.startsWith("/api/")) return send(res, new Response("No encontrado", { status: 404 }));
		if (!["GET", "HEAD"].includes(req.method)) return send(res, new Response("Método no permitido", { status: 405 }));
		let decoded;
		try {
			decoded = decodeURIComponent(local);
		} catch {
			return send(res, new Response("Ruta no válida", { status: 400 }));
		}
		const file = path.resolve(staticDir, "." + decoded);
		if (file !== staticDir && !file.startsWith(staticDir + path.sep)) return send(res, new Response("No encontrado", { status: 404 }));
		let chosen = file;
		if (decoded === "/" || !path.extname(decoded)) chosen = path.join(staticDir, "index.html");
		if (!fs.existsSync(chosen) || !fs.statSync(chosen).isFile()) return send(res, new Response("No encontrado", { status: 404 }));
		const mime = {
			".html": "text/html;charset=utf-8",
			".js": "text/javascript;charset=utf-8",
			".css": "text/css;charset=utf-8",
			".jpg": "image/jpeg",
			".png": "image/png",
			".webp": "image/webp",
			".svg": "image/svg+xml",
			".woff2": "font/woff2",
			".pdf": "application/pdf"
		}[path.extname(chosen)] || "application/octet-stream";
		res.writeHead(200, {
			"Content-Type": mime,
			"Cache-Control": path.extname(chosen) === ".html" ? "no-cache" : "public,max-age=3600",
			"X-Content-Type-Options": "nosniff"
		});
		if (req.method === "HEAD") res.end();
		else fs.createReadStream(chosen).pipe(res);
	});
}
var queue = Promise.resolve();
http.createServer((req, res) => {
	queue = queue.then(() => handle(req, res)).catch((e) => {
		console.error("Error al procesar la solicitud:", e.message);
		if (!res.headersSent) {
			res.writeHead(500, { "Content-Type": "application/json" });
			res.end(JSON.stringify({ error: "No se pudo procesar. Inténtalo de nuevo." }));
		} else res.end();
	});
}).listen(port, "127.0.0.1", () => console.log(`Larimar VPS en 127.0.0.1:${port}${base}/`));
//#endregion
export {};
